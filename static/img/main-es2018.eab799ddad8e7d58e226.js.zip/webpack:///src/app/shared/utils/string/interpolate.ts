function interpolate(template: string, params: object): string {
    const keys = Object.keys(params);
    const vals = Object.values(params);

    return new Function(...keys, `return \`${template}\`;`)(...vals);
}

export default interpolate;
