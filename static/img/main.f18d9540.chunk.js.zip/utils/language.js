import config from "config.json";
import { objectIsEmpty } from "./index";
import { getCookie, setCookie } from "./cookie";

export const localeRegExp = /\/([a-z]{2}((_|-)[A-z]{2})?)(\/|$)/;

export const getDefaultLocale = (brand) => {
	return (config?.brands?.[brand]?.defaultLocale || config.defaultLocale)
		.toLowerCase()
		.replace("_", "-");
};

export const getDefaultLocaleCookie = (brand) => {
	return (
		config?.brands?.[brand]?.defaultLocaleCookie || config.defaultLocaleCookie
	);
};

export const getDefaultLocaleCookieProperty = (brand) => {
	return (
		config?.brands?.[brand]?.defaultLocaleCookieProperty ||
		config.defaultLocaleCookieProperty
	);
};

export const processLanguageSelectorUrl = (url) => {
	if (url.match(/^http/)) return url;
	const currentLocale = window.location.pathname.match(localeRegExp)?.[0] || "";
	const targetUrl = window.location.href.replace(window.location.origin, "");

	if (currentLocale) {
		return targetUrl.replace(currentLocale, url);
	} else {
		return url.concat(targetUrl.replace("/", ""));
	}
};

export const setLanguageCookies = (cookies) => {
	const cookieExpirationInDays = 2;
	for (const cookieJarName in cookies) {
		const cookie = getCookie(cookieJarName);
		try {
			if (cookie) {
				const cookieDecoded = JSON.parse(decodeURIComponent(cookie));
				if (cookieDecoded) {
					setCookie(
						cookieJarName,
						encodeURIComponent(
							JSON.stringify({
								...cookieDecoded,
								...cookies[cookieJarName],
							})
						),
						cookieExpirationInDays
					);
				}
			}
		} catch (error) {
			console.error(error);
		}
	}
};

export const getLanguageCookies = (
	cookiesToSet,
	locale,
	localeCurrency,
	preferredLanguage
) => {
	const cookiesToSetNew = {};
	if (!objectIsEmpty(cookiesToSet)) {
		for (const cookieJar in cookiesToSet) {
			cookiesToSetNew[cookieJar] = {};
			for (const cookie in cookiesToSet[cookieJar]) {
				switch (cookie) {
					case "preferredRegion":
						cookiesToSetNew[cookieJar][cookie] = locale;
						break;
					case "localeCurrency":
						cookiesToSetNew[cookieJar][cookie] = localeCurrency;
						break;
					case "preferredLanguage":
						cookiesToSetNew[cookieJar][cookie] = preferredLanguage;
						break;
					case "language":
						cookiesToSetNew[cookieJar][cookie] = preferredLanguage;
						break;
					default:
						cookiesToSetNew[cookieJar][cookie] =
							cookiesToSet[cookieJar][cookie];
				}
			}
		}
	}
	return cookiesToSetNew;
};

export const getGDPRLocale = (brand) => {
	const gdprHostnames = config?.brands?.[brand]?.gdprHostnames;
	if (!gdprHostnames) return null;
	let locale;

	for (const hostname in gdprHostnames) {
		if (
			window.location.hostname.includes(hostname) &&
			gdprHostnames[hostname]
		) {
			locale = gdprHostnames[hostname];
			break;
		}
	}
	return locale;
};
