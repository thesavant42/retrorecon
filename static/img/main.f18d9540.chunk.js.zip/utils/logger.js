import config from "../config.json";

const Logger = class {
	constructor() {
		this.apiUrl = config.logger.apiUrl || false;
		this.maxStringLength = config.logger.maxStringLength || false;
		this._log = console.log;
		this._error = console.error;
		this._warn = console.warn;
		this._debug = console.debug;
	}

	log(message, ...args) {
		const messages = this.parseMessage(args);
		this._log(message, ...messages);
	}

	warn(message, ...args) {
		const messages = this.parseMessage(args);
		this._warn(message, ...messages);
	}

	debug(message, ...args) {
		const messages = this.parseMessage(args);
		this._debug(message, ...messages);
	}

	error(message, ...args) {
		const messages = this.parseMessage(args);
		this._error(message, ...messages);

		if (this.apiUrl) {
			this.send(message, ...args);
		}
	}

	async send(...args) {
		const logMessage = this.truncateMessageObject(args);

		const response = await fetch(this.apiUrl, {
			method: "POST",
			body: JSON.stringify(logMessage),
		});

		return response.json();
	}

	truncateMessageObject(logMessage, depth = 4) {
		for (const prop in logMessage) {
			if (
				typeof logMessage[prop] === "string" &&
				logMessage[prop].length > this.maxStringLength
			) {
				// protect against assignment errors on
				// non-writable properties in strict mode
				try {
					logMessage[prop] = this.maxStringLength
						? this.truncateMessageString(logMessage[prop])
						: logMessage[prop];
				} catch (error) {
					// fail silently
				}
			} else if (
				typeof logMessage[prop] === "object" &&
				logMessage[prop] !== null &&
				depth
			) {
				// condition is also true for arrays
				this.truncateMessageObject(logMessage[prop], depth);
			}
		}
		return logMessage;
	}

	truncateMessageString(str) {
		return str.substr(0, this.maxStringLength) + "...[truncated]";
	}

	parseMessage(args) {
		let messages;

		// Iterate over array
		messages = args.map((elem) => {
			if (typeof elem !== "string") {
				return elem;
			}
			let str;
			try {
				// Try to parse JSON and access message prop
				// Fallback to whole JSON object
				const data = JSON.parse(elem);
				str = data.message || elem;
			} catch (e) {
				// Plain string - Eat the error
				str = elem;
			}
			return str;
		});
		return messages;
	}
};

export default new Logger();
