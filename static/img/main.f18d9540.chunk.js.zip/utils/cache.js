import { cache } from "config.json";

const openCacheStorage = async () => {
	try {
		return await caches?.open(cache.name);
	} catch (error) {
		console.log(error);
	}
	return null;
};

export const validateCache = async (cacheStorage, key) => {
	if (cacheStorage && key) {
		try {
			const cacheResult = (await cacheStorage?.match(key)) || null;
			if (cacheResult) {
				const expirationDate = Date.parse(
					cacheResult.headers.get(cache.expirationHeader)
				);
				if (expirationDate < new Date()) {
					await cacheStorage.delete(key);
					return null;
				}
			}
			return cacheResult;
		} catch (error) {
			console.log(error);
		}
	}
	return null;
};

export const getCache = async (key) => {
	if (key) {
		const cacheStorage = await openCacheStorage();
		if (cacheStorage) {
			return await validateCache(cacheStorage, key);
		}
	}
	return null;
};

export const setCache = async (key, response, cacheValidMinutes = 5) => {
	if (key && response) {
		try {
			const cacheStorage = await openCacheStorage();
			if (cacheStorage) {
				const expires = new Date();
				const seconds = 60;
				expires.setSeconds(expires.getSeconds() + cacheValidMinutes * seconds);
				const cachedResponseFields = {
					status: response.status,
					statusText: response.statusText,
					headers: { [cache.expirationHeader]: expires.toUTCString() },
				};
				response.headers.forEach((v, k) => {
					cachedResponseFields.headers[k] = v;
				});
				await cacheStorage.put(
					key,
					new Response(response.body, cachedResponseFields)
				);
			}
		} catch (error) {
			console.log(error);
		}
	}
};

export const cleanExpiredCache = async () => {
	try {
		const cacheStorage = await openCacheStorage();
		cacheStorage?.keys().then((keyList) => {
			for (let index = 0; index < keyList.length; index++) {
				validateCache(cacheStorage, keyList[index].url);
			}
		});
	} catch (error) {
		console.error(error);
	}
};
