export const getCookie = (key) => {
	if (!key) return;
	try {
		const cookie = document.cookie
			.split("; ")
			.find((row) => row.split("=")[0] === key);
		return cookie ? cookie.split("=")[1] : "";
	} catch (error) {
		console.error(error);
	}
};

export const setCookie = (key, value, numberOfDays) => {
	if (!key) return;
	try {
		const expires = new Date();
		expires.setDate(expires.getDate() + numberOfDays);
		document.cookie = `${key}=${value}; expires=${expires.toUTCString()}; path=/`;
	} catch (error) {
		console.error(error);
	}
};

export const removeCookie = (key) => {
	if (!key) return;
	try {
		document.cookie = `${key}=; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
	} catch (error) {
		console.error(error);
	}
};
