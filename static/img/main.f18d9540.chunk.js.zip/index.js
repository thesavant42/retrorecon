import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./styles/main.scss";
import ContextProvider from "./Context";
import Logger from "./utils/logger";
import { cleanExpiredCache } from "./utils/cache";

if (false && process.env.NODE_ENV !== "development") {
	console.log = (...args) => {
		Logger.log(...args);
	};
	console.warn = (...args) => {
		Logger.warn(...args);
	};
	console.debug = (...args) => {
		Logger.error(...args);
	};
	console.error = (...args) => {
		Logger.error(...args);
	};
}

const render = () => {
	const root = document.createElement("div");
	root.id = "syndicated-root";
	document.body.appendChild(root);

	ReactDOM.render(
		<React.StrictMode>
			<ContextProvider>
				<App />
			</ContextProvider>
		</React.StrictMode>,
		root
	);
};

cleanExpiredCache();
render();
