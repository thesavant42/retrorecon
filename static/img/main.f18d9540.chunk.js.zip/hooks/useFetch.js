import { useState, useEffect } from "react";
import { defaultBaseApiUrl, brands } from "config.json";
import { getEnvironment } from "utils";
import {
	loadBrandParam,
	loadLocaleParam,
	validateAndAddStoreParam,
} from "utils/paramsValidation";
import { getCache, setCache } from "utils/cache";

const userTypeKey = "userType";
const brand = loadBrandParam();
const appEnv = getEnvironment();

const apiUrl = (() => {
	let serviceEnv = "";
	switch (appEnv) {
		case "development":
		case "latest":
			serviceEnv = "latest.";
			break;
		case "stage":
			serviceEnv = "stage.";
			break;
		case "lt01":
			serviceEnv = brands[brand].useLt01ApiPrefix ? "lt01." : "load.";
			break;
		default:
			serviceEnv = "";
	}
	return (brands[brand]?.baseApiUrl || defaultBaseApiUrl).replace(
		"{env}",
		serviceEnv
	);
})();

const urlInterceptor = (url, locale) => {
	if (url?.indexOf("/navigation/") === 0) {
		url = new URL(`${apiUrl}${url.replace("/navigation", "")}`);
		url.searchParams.append("brand", brand);
		url.searchParams.append("locale", locale);
		validateAndAddStoreParam(url);
		if (
			url.pathname.indexOf("/content/") &&
			!url.searchParams.has(userTypeKey)
		) {
			url.searchParams.append(
				userTypeKey,
				url.searchParams.has("store") ? "TRAVEL_AGENT" : "GUEST"
			);
		}
		url = url.href;
	}
	return url;
};

const useFetch = (url, options, cacheValidMinutes = 0, trigger) => {
	const locale = loadLocaleParam();
	const [response, setResponse] = useState(null);
	const [error, setError] = useState(null);
	const [loading, setLoading] = useState(false);
	useEffect(() => {
		const abortController = new AbortController();
		const signal = abortController.signal;
		const doFetch = async () => {
			setError(null);
			setLoading(true);
			try {
				let res;
				const requestUrl = urlInterceptor(url, locale);
				if (cacheValidMinutes) {
					res = await getCache(requestUrl);
				}
				if (!res) {
					res = await fetch(requestUrl, { ...options, ...{ signal } });
					if (!res.ok) {
						const responseError = {
							body: await res.json(),
							message: res.message || "Request error",
							status: res.status,
							statusText: res.statusText,
							type: res.type,
						};
						throw responseError;
					}
					if (cacheValidMinutes) {
						await setCache(requestUrl, res.clone(), cacheValidMinutes);
					}
				}
				const json = await res.json();
				if (!signal.aborted) {
					setResponse(json);
				}
			} catch (e) {
				if (!signal.aborted) {
					setResponse(null);
					setError(e);
				}
			} finally {
				if (!signal.aborted) {
					setLoading(false);
				}
			}
		};
		if (url) {
			doFetch();
		}
		return () => {
			abortController?.abort();
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [trigger]);
	return { response, error, loading };
};
export default useFetch;
