import Title from "components/footer/Title";

const mainClass = "syndicated-footer__item";

const Item = ({ title, id, children, emptyTitle = false }) => (
	<li
		className={`syndicated-footer__item syndicated-footer--${id}${
			emptyTitle ? ` ${mainClass}--empty-title` : ""
		}`}
	>
		<Title title={title} empty={emptyTitle} />
		{children}
	</li>
);

export default Item;
