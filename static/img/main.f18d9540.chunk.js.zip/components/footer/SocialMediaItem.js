import Link from "components/shared/Link";
import Item from "components/footer/Item";
import SocialMediaIcon from "./SocialMediaIcon";

const SocialMediaItem = ({ title, descriptions: links = [], id }) => (
	<Item title={title} id={id}>
		<div
			className={`syndicated-footer--social-media  syndicated-footer--${id}__content`}
		>
			{links?.map(({ link, image, id }, index) => (
				<div key={index}>
					{link && (
						<Link {...link} rel="noreferrer">
							{image && (
								<div className={`syndicated-social-icon__wrapper`}>
									<SocialMediaIcon
										src={image.url}
										title={link.title}
										className={`syndicated-social-icon--${id}`}
									/>
								</div>
							)}
							<span>{link.title}</span>
						</Link>
					)}
				</div>
			))}
		</div>
	</Item>
);

export default SocialMediaItem;
