import FooterWrapper from "components/shared/FooterWrapper";
import Legal from "components/legal/Legal";
import Columns from "components/footer/Columns";
import SocialMediaItem from "components/footer/SocialMediaItem";
import RelatedDisneySites from "components/footer/RelatedDisneySites";
import SocialInformationItem from "components/footer/SocialInformationItem";
import DisneyReservationCenter from "components/footer/DisneyReservationCenter";
import { useContext, useState } from "react";
import Icon from "components/shared/Icon";
import { Context } from "Context";
import useCheckMediaQuery from "hooks/useCheckMediaQuery";
import { mobileMediaQuery } from "config.json";

const mainClass = "syndicated-footer";
const syndicatedFooterContainerClass = `${mainClass}__container`;
const syndicatedFooterSocialMediaContainerClass = `${mainClass}__social-media-and-information-container`;

const Footer = () => {
	const {
		config: { brand, showRelatedDisneySites },
		footerData: { column, footer, labels, relatedDisneySites },
	} = useContext(Context);
	const [showOnMobile, setShowOnMobile] = useState(false);
	const isMobileView = useCheckMediaQuery(mobileMediaQuery);

	const renderSocialMediaAndInformationItem = (
		content,
		index,
		componentsToRender
	) => {
		if (["stayConnected", "disneyParks"].includes(content.id)) {
			componentsToRender.push(<SocialMediaItem {...content} key={index} />);
		} else {
			componentsToRender.push(
				<SocialInformationItem {...content} key={index} />
			);
		}
	};

	const renderSocialMediaAndInformationItems = () => {
		const componentsToRender = [];
		footer.modules?.forEach((content, index) => {
			if (content.modules) {
				const subComponents = [];
				content.modules.forEach((moduleContent, subIndex) => {
					renderSocialMediaAndInformationItem(
						moduleContent,
						subIndex,
						subComponents
					);
				});
				componentsToRender.push(
					<ul
						className={`${syndicatedFooterSocialMediaContainerClass}__group`}
						key={index}
					>
						{subComponents}
					</ul>
				);
			} else {
				renderSocialMediaAndInformationItem(content, index, componentsToRender);
			}
		});
		return componentsToRender;
	};

	return (
		<FooterWrapper>
			<div className={`${mainClass} ${mainClass}--${brand}`}>
				{labels && (
					<DisneyReservationCenter
						title={labels.drcCtaTitle}
						subtitle={labels.drcCtaSubtitle}
					/>
				)}
				<div
					className={`${syndicatedFooterContainerClass}${
						showOnMobile ? ` ${syndicatedFooterContainerClass}--show` : ""
					}`}
				>
					<button
						className={`${syndicatedFooterContainerClass}__button${
							showOnMobile
								? ` ${syndicatedFooterContainerClass}__button--active`
								: ""
						}`}
						onClick={() => setShowOnMobile(!showOnMobile)}
					>
						<Icon icon={"norgie-closed"} rotate={showOnMobile} />
						{labels?.showMoreLinks}
					</button>
					<div
						aria-hidden={isMobileView && !showOnMobile}
						className={`${syndicatedFooterContainerClass}__content ${syndicatedFooterContainerClass}__content${
							showOnMobile ? "--show" : ""
						}`}
					>
						{column && (
							<Columns
								columns={column.modules}
								accessibleText={labels?.accessibiltyTextFooterLinks}
							/>
						)}
						{footer && (
							<ul className={syndicatedFooterSocialMediaContainerClass}>
								{renderSocialMediaAndInformationItems()}
							</ul>
						)}
						{relatedDisneySites && showRelatedDisneySites && (
							<RelatedDisneySites
								title={relatedDisneySites.title}
								linksColumns={relatedDisneySites.modules}
							/>
						)}
					</div>
				</div>
			</div>
			<Legal wrap={false} />
		</FooterWrapper>
	);
};

export default Footer;
