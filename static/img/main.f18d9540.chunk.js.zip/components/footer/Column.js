import Link from "components/shared/Link";
import Title from "components/footer/Title";

const mainClass = "syndicated-footer__list__column__section";

const Column = ({ title, id, webLinkList = [] }) => {
	return (
		<div className={`${mainClass}${id ? ` ${mainClass}--${id}` : ""}`}>
			<Title title={title} />
			<nav>
				<ul className={`${mainClass}__group`}>
					{webLinkList?.map((link, index) => (
						<li key={index} className={`${mainClass}__group__item`}>
							<Link {...link} className="syndicated-footer__link" />
						</li>
					))}
				</ul>
			</nav>
		</div>
	);
};

export default Column;
