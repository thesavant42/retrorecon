import { getCdn } from "utils";

const SocialMediaIcon = ({ className, title = "", src }) => (
	<img
		src={src.indexOf("http") === 0 ? src : `${getCdn(true)}/icons/${src}`}
		alt={title}
		title={title}
		className={`syndicated-social-icon ${className}`}
	/>
);

export default SocialMediaIcon;
