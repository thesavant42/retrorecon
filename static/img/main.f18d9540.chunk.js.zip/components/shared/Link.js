import { useContext } from "react";
import AccessibleText from "./AccessibleText";
import { Context } from "Context";
import { trackLink } from "utils/analyticsFramework";

const interstitialPrefix = "interstitial";
const modalLayer = "modalLayer";
const storePrefix = "/reservations/";

const Link = ({
	accessibleText = "",
	analyticsLinkId = null,
	children = null,
	className = null,
	handleClick = null,
	href,
	title = "",
	tabIndex = null,
	target = "_self",
	rel = null,
	role = null,
	byPassBasePath = false,
}) => {
	const {
		headerData: { interstitial: headerInterstitials = {} } = {},
		footerData: { interstitial: footerInterstitials = {} } = {},
		legalFooterData: { interstitial: legalFooterInterstitials = {} } = {},
		setModal,
		config: { basePath, store },
	} = useContext(Context);

	const interstitials = {
		...headerInterstitials,
		...footerInterstitials,
		...legalFooterInterstitials,
	};

	if (!href) {
		console.error("No href present");
		return null;
	}

	if (!title && children === null && !accessibleText) {
		console.error("No title or content present for: ", href);
		return null;
	}

	if (href[0] === "/") {
		if (store) {
			href = `${storePrefix}${store}${href}`;
		}
		if (!byPassBasePath) {
			href = `${basePath}${href}`;
		}
	}

	const handleInterstitial = (e) => {
		const modal = interstitials[target];
		if (modal) {
			e.preventDefault();
			modal.href = href;
			setModal(modal);
		}
	};

	const handleModalLayer = (e) => {
		const modal = interstitials[href.match(/[^#]+/g)[0]];
		if (modal) {
			e.preventDefault();
			setModal({ ...modal, href: href.match(/[^#]+/g)[1] || modal.href });
		}
	};

	const handleTriggerAnalytics = (e) => {
		const linkId = `${analyticsLinkId}_${
			e.type === "click" ? "CLICK" : "HOVER"
		}`;

		if (analyticsLinkId) {
			trackLink({ linkId });
		}
	};

	return (
		<a
			href={href}
			onClick={(e) => {
				target && target.includes(interstitialPrefix) && handleInterstitial(e);
				target && target.includes(modalLayer) && handleModalLayer(e);
				handleClick && handleClick(e);
				analyticsLinkId && handleTriggerAnalytics(e);
			}}
			onMouseEnter={(e) => {
				analyticsLinkId && handleTriggerAnalytics(e);
			}}
			name={analyticsLinkId ? `&lid=${analyticsLinkId}` : null}
			className={className}
			tabIndex={tabIndex}
			target={target}
			role={role}
			rel={rel}
		>
			{children || title}
			{accessibleText && <AccessibleText>{accessibleText}</AccessibleText>}
		</a>
	);
};

export default Link;
