const Title = ({ title = "", subTitle = "", name = "", noWrap = false }) => {
	const mainClass = "syndicated-title";
	let classes = mainClass;
	if (name) classes += ` ${mainClass}--${name}`;

	let mainTitleClass = `${mainClass}__heading`;
	if (noWrap) mainTitleClass += ` ${mainTitleClass}--no-wrap`;

	return (
		(title || subTitle) && (
			<div className={classes}>
				{title && (
					<div
						className={mainTitleClass}
						dangerouslySetInnerHTML={{ __html: title }}
					></div>
				)}
				{subTitle && (
					<div
						className={`${mainClass}__subtitle`}
						dangerouslySetInnerHTML={{ __html: subTitle }}
					/>
				)}
			</div>
		)
	);
};

export default Title;
