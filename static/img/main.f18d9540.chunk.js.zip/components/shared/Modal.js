import { useContext, useEffect, useState, useRef, Fragment } from "react";
import { Context } from "Context";
import Separator from "./Separator";
import Button from "./Button";
import { focusableElements } from "config.json";

const bodyOnModalOpen = "syndicated-overflow-hidden";
const escapeKey = 27;
const tabKey = 9;

const syndicatedModalClass = "syndicated-modal";
const syndicatedModalContainerClass = `${syndicatedModalClass}__container`;
const syndicatedModalTitleClass = `${syndicatedModalClass}__title`;
const syndicatedModalContentClass = `${syndicatedModalClass}__content`;
const syndicatedModalFooterClass = `${syndicatedModalClass}__footer`;

const Modal = () => {
	const [focusableModalElements, setFocusableModalElements] = useState(null);
	const [firstElement, setFirstElement] = useState(null);
	const [lastElement, setLastElement] = useState(null);

	const modalRef = useRef(null);
	const {
		modal,
		setModal,
		config: { brand },
	} = useContext(Context);

	const handleClose = () => setModal(false);

	const handleTabKey = (e) => {
		if (!e.shiftKey && document.activeElement === lastElement) {
			firstElement.focus();
			return e.preventDefault();
		}

		if (e.shiftKey && document.activeElement === firstElement) {
			lastElement.focus();
			e.preventDefault();
		}
	};

	useEffect(() => {
		if (modalRef.current) {
			setFocusableModalElements(
				modalRef.current.querySelectorAll(focusableElements)
			);
		}
	}, [modal]);

	useEffect(() => {
		if (focusableModalElements) {
			setFirstElement(focusableModalElements[0]);
			setLastElement(focusableModalElements[focusableModalElements.length - 1]);
		}
	}, [focusableModalElements]);

	const keyListener = (e) => {
		if (![escapeKey, tabKey].includes(e.keyCode)) return null;
		const listener = e.keyCode === tabKey ? handleTabKey : handleClose;
		return listener(e);
	};

	useEffect(() => {
		if (modal) {
			modalRef.current.focus();
			document.body.classList.add(bodyOnModalOpen);
		}
		return () => {
			document.body.classList.remove(bodyOnModalOpen);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [modal]);

	const renderContent = ({
		title,
		description,
		content,
		primaryButton,
		secondaryButton,
		href,
		target,
	}) => {
		return (
			<Fragment>
				{title && (
					<div
						className={`${syndicatedModalTitleClass} ${syndicatedModalTitleClass}--${brand}`}
					>
						{title}
					</div>
				)}
				{description && (
					<div
						className={`${syndicatedModalContentClass} ${syndicatedModalContentClass}--${brand}`}
						dangerouslySetInnerHTML={{ __html: description }}
					/>
				)}
				{content && (
					<div
						className={`${syndicatedModalContentClass} ${syndicatedModalContentClass}--${brand}`}
					>
						{content}
					</div>
				)}
				{(primaryButton || secondaryButton) && (
					<Fragment>
						<Separator />
						<div
							className={`${syndicatedModalFooterClass} ${syndicatedModalFooterClass}--${brand}`}
						>
							{secondaryButton && (
								<Button
									onClick={handleClose}
									secondary={true}
									title={secondaryButton}
								/>
							)}
							{primaryButton && (
								<Button
									title={primaryButton}
									onClick={(e) => {
										href && window.open(href, target);
										handleClose();
									}}
								/>
							)}
						</div>
					</Fragment>
				)}
			</Fragment>
		);
	};

	return modal ? (
		<div
			className={`${syndicatedModalClass} ${syndicatedModalClass}--${brand}`}
			role="dialog"
			aria-modal="true"
			ref={modalRef}
			tabIndex="-1"
			onKeyDown={keyListener}
		>
			<div
				className={`${syndicatedModalContainerClass} ${syndicatedModalContainerClass}--${brand}`}
			>
				{modal && renderContent(modal)}
			</div>
		</div>
	) : null;
};

export default Modal;
