import { Context } from "Context";
import { useContext, useEffect, useState } from "react";
import Loading from "./Loading";
import useFetch from "hooks/useFetch";
import { content, brands } from "config.json";

const cacheMinutes = 5;
const mainClass = "syndicated-footer-wrapper";

const FooterWrapper = ({ children }) => {
	const {
		config: { brand, legal, footer, theme, store },
		footerData,
		legalFooterData,
		setConfig,
		setFooterData,
		setLegalFooterData,
		profileData: { userType },
	} = useContext(Context);
	const [footerWrapperUrl, setFooterWrapperUrl] = useState("");
	const { response, error } = useFetch(
		footerWrapperUrl,
		{},
		cacheMinutes,
		footerWrapperUrl
	);

	let classes = `${mainClass} ${mainClass}--${brand}`;

	if (theme) {
		classes += ` syndicated-theme--${theme}`;
	}

	if (store) {
		classes += ` ${mainClass}__store ${mainClass}__store--${store}`;
	}

	useEffect(() => {
		const isUserTypeRequired =
			brands?.[brand]?.isUserTypeRequiredForContentRequest;
		if (!isUserTypeRequired || (isUserTypeRequired && userType)) {
			const footerBaseUrl =
				legal && !footer ? content.apiUrl.legal : content.apiUrl.footer;
			setFooterWrapperUrl(
				isUserTypeRequired && userType
					? `${footerBaseUrl}?userType=${userType}`
					: footerBaseUrl
			);
		}
	}, [userType, brand, footer, legal]);

	useEffect(() => {
		if (response) {
			if (legal && !footer) {
				setLegalFooterData(response);
			} else {
				setFooterData(response);
			}
			setConfig((config) => ({ ...config, ...(response.context || {}) }));
		} else if (error) {
			setFooterData({ error: true, loading: false });
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [error, response]);

	return (
		<footer className={classes}>
			{footerData.loading && legalFooterData.loading && <Loading />}
			{((!footerData.loading && !footerData.error) ||
				(!legalFooterData.loading && !legalFooterData.error)) && (
				<div className="syndicated-footer-wrapper__container">{children}</div>
			)}
		</footer>
	);
};

export default FooterWrapper;
