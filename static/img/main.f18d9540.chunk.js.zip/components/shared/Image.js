const baseClass = "syndicated-image";

const Image = ({
	name = "",
	image: {
		url = "",
		title = "",
		alt = title,
		width = null,
		height = null,
	} = {},
}) => {
	const modifier = name ? `${baseClass}--${name}` : "";

	if (!url) {
		return null;
	}

	return (
		<img
			className={`${baseClass} ${modifier}`}
			src={url}
			alt={alt}
			title={title}
			width={width}
			height={height}
		/>
	);
};

export default Image;
