import Container from "components/shared/Container";
import Icon from "components/shared/Icon";
import Link from "components/shared/Link";
import { useContext, useEffect, useState } from "react";
import { getCookie, setCookie } from "utils/cookie";
import { Context } from "Context";

const classTogglesCookieKey = "classToggles_jar";
const travelTradeMainClass = "syndicated-travel-trade";
const travelTradeAgentInformationClass = `${travelTradeMainClass}__agent-information`;
const canadaStoreSuffix = "-ca";
const guestSensitiveClass = "guestSensitive";

const removeSymbolsFromText = (text) => {
	if (text) {
		return text.replace(/\+/g, " ");
	}
	return "";
};

const joinTexts = (firstText, secondText) => {
	return removeSymbolsFromText(
		`${firstText || ""}${firstText && secondText ? " " : ""}${secondText || ""}`
	);
};

const getClassTogglesCookieValue = () => {
	const currentCookieValue = getCookie(classTogglesCookieKey);
	if (currentCookieValue) {
		try {
			const parsedValue = JSON.parse(decodeURIComponent(currentCookieValue));
			if (parsedValue && typeof parsedValue === "object") {
				return parsedValue;
			}
		} catch (error) {
			console.error(error);
		}
	}
	return { travelAgentInfoHidden: false };
};

const setClassTogglesCookie = (travelAgentInfoHidden) => {
	const classTogglesCookieValue = getClassTogglesCookieValue() || {};
	try {
		setCookie(
			classTogglesCookieKey,
			encodeURIComponent(
				JSON.stringify({ ...classTogglesCookieValue, travelAgentInfoHidden })
			),
			365
		);
	} catch (error) {
		console.error(error);
	}
};

const TravelTrade = () => {
	const {
		headerData: { chrome },
		profileData: { travelAgent },
		config: { store },
	} = useContext(Context);
	const [expand, setExpand] = useState(
		!Boolean(getClassTogglesCookieValue()?.travelAgentInfoHidden)
	);
	const [travelAgentData, setTravelAgentData] = useState(null);
	const [travelAgentInfoLink, setTravelAgentInfoLink] = useState(null);

	const readTravelAgentDataFromCookie = () => {
		const ticketDataJarCookie = getCookie("TICKET_DATA_jar");
		if (ticketDataJarCookie) {
			try {
				const travelAgentCookieData = JSON.parse(
					decodeURIComponent(ticketDataJarCookie)
				);
				if (
					travelAgentCookieData?.firstName &&
					travelAgentCookieData?.agencyName
				) {
					const {
						email: emailAddress,
						phone,
						addressLine1: line1,
						addressLine2: line2,
						city,
						zipCode: postalCode,
						state: stateOrProvince,
						country,
						agencyName: name,
						partnerId,
						partnerIdType,
						...rest
					} = travelAgentCookieData;
					setTravelAgentData({
						emailAddress,
						travelAgency: {
							name,
							partnerId,
							partnerIdType,
							phone,
							address: {
								line1,
								line2,
								city,
								stateOrProvince,
								postalCode,
								country,
							},
						},
						...rest,
					});
				}
			} catch (error) {
				console.log(error);
			}
		}
	};

	useEffect(() => {
		if (travelAgentData) {
			setClassTogglesCookie(!expand);
			document.dispatchEvent(
				new CustomEvent("navigationTravelAgentInfo", { detail: expand })
			);
		}
	}, [expand, travelAgentData]);

	useEffect(() => {
		if (travelAgent?.firstName && travelAgent?.travelAgency) {
			setTravelAgentData(travelAgent);
		} else if (travelAgent?.readDataFromCookie) {
			readTravelAgentDataFromCookie();
		}
	}, [travelAgent]);

	useEffect(() => {
		if (
			chrome?.travelAgentInfoLinkCA &&
			store?.substring(store?.length - canadaStoreSuffix.length) ===
				canadaStoreSuffix
		) {
			setTravelAgentInfoLink(chrome?.travelAgentInfoLinkCA);
		} else {
			setTravelAgentInfoLink(chrome?.travelAgentInfoLink);
		}
	}, [chrome, store]);

	return travelAgentData ? (
		<div className={travelTradeMainClass}>
			<Container direction="column">
				<div
					className={`${travelTradeAgentInformationClass} ${travelTradeAgentInformationClass}--${
						expand ? "expanded" : " collapsed"
					}`}
				>
					<div className={`${travelTradeAgentInformationClass}__main`}>
						<h3 className={`${guestSensitiveClass}High`}>
							{removeSymbolsFromText(
								`${travelAgentData.firstName} ${travelAgentData.lastName}`
							)}
						</h3>
						<p className={guestSensitiveClass}>
							{removeSymbolsFromText(travelAgentData.travelAgency?.name)}
						</p>
					</div>
					<div className={`${travelTradeAgentInformationClass}__details`}>
						<p className={guestSensitiveClass}>
							{[
								joinTexts(
									travelAgentData.travelAgency?.address?.line1,
									travelAgentData.travelAgency?.address?.line2
								),
								travelAgentData.travelAgency?.address?.city,
								travelAgentData.travelAgency?.address?.stateOrProvince,
								travelAgentData.travelAgency?.address?.postalCode,
							]
								.filter((item) => item)
								.join(", ")}
						</p>
						<p>
							<span className={guestSensitiveClass}>
								{travelAgentData.travelAgency?.phone
									? `${chrome?.phoneLabel?.toUpperCase() || ""}: ${
											travelAgentData.travelAgency.phone
									  } | `
									: ""}
							</span>
							<span>
								{travelAgentData.travelAgency?.partnerIdType ||
									chrome?.travelAgentPartnerIdType}
								: {travelAgentData.travelAgency.partnerId}
							</span>
						</p>
					</div>
					<div className={`${travelTradeAgentInformationClass}__link`}>
						{travelAgentInfoLink && <Link {...travelAgentInfoLink} />}
					</div>
				</div>
				<button
					className={`${travelTradeMainClass}__button${
						expand ? ` ${travelTradeMainClass}__button--expanded` : ""
					}`}
					onClick={() => setExpand(!expand)}
				>
					{expand ? chrome?.hideTravelAgentInfo : chrome?.showTravelAgentInfo}
					<Icon
						icon="icon_expand-show-more"
						className={expand ? "syndicated-icon--rotate-180" : ""}
					/>
				</button>
			</Container>
		</div>
	) : null;
};

export default TravelTrade;
