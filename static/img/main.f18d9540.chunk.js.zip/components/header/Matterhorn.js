import { matterhorn } from "config.json";
import useScript from "hooks/useScript";

const createScriptConfig = () => {
	const gocConfig = document.createElement("script");
	gocConfig.id = "gocConfig";
	gocConfig.type = "text/javascript";
	gocConfig.text = `var GOC = { opts: ${JSON.stringify(
		matterhorn.options
	)}, queue: [ ] };`;
	document.head.appendChild(gocConfig);
};

const toggle = (open) => {
	checkElement("#goc-bar")
		.then((e) => {
			const innerElem = document.querySelector(".goc-bound");

			const isFirstTime =
				!document.querySelector(".goc-bound.fade-out") &&
				!document.querySelector(".goc-bound.fade-in");

			if (isFirstTime) {
				e.style.display = "none";
				e.classList.add("syndicated-display-matterhorn");
				innerElem.classList.add("fade-out");
			} else if (!open) {
				innerElem.classList.remove("fade-in");
				innerElem.classList.add("fade-out");
				setTimeout(() => {
					e.style.display = "none";
				}, 400);
			} else {
				e.style.display = "";
				innerElem.classList.remove("fade-out");
				innerElem.classList.add("fade-in");
			}
		})
		.catch(() => {
			console.error("error loading matterhorn");
		});
};

const checkElement = (selector) => {
	const elem = document.querySelector(selector);
	if (elem === null) {
		return onElementReady().then(() => checkElement(selector));
	} else {
		return Promise.resolve(elem);
	}
};

const onElementReady = () => {
	return new Promise((resolve) => {
		window.requestAnimationFrame(resolve);
	});
};

const Matterhorn = ({ open }) => {
	const checkGocConfig = document.querySelector("#gocConfig");
	const i18n = "en";
	const scriptLang = matterhorn.scripts[0].url.replace(/i18n/g, i18n);

	if (!checkGocConfig) {
		createScriptConfig();
	}

	const status = useScript(scriptLang, matterhorn.scripts[0].position);

	if (status === "ready") {
		toggle(open);
	}

	return null;
};

export default Matterhorn;
