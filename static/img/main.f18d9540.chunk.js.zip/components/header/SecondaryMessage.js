import React, { useContext, useEffect, useState } from "react";
import { objectIsEmpty, getCdn } from "utils";
import { getCookie, setCookie } from "utils/cookie";
import { Context } from "Context";

const SecondaryMessage = () => {
	const AFFILIATION_TYPE_NAME = "CASTAWAYCLUB";
	const GENERIC_MESSAGE = "DEFAULT";
	const TRAVEL_AGENT = "TRAVELAGENT";
	const dismissedCookieName = "earlyBookingMessageClosed";
	const travelAgentCookieName = "TICKET_DATA_jar";

	const {
		headerData: { secondaryMessage },
		profileData: { user },
	} = useContext(Context);
	const [bannerMessage, setBannerMessage] = useState(null);
	const [dismissed, setDismissed] = useState(null);
	const [isTravelAgent, setIsTravelAgent] = useState(null);

	const generateBanner = (banner) => {
		if (objectIsEmpty(banner)) {
			banner = secondaryMessage?.descriptions.find(
				({ id }) => id === GENERIC_MESSAGE
			);
		}
		const firstName = user?.firstName;
		const closeAriaLabel = banner?.closeAriaLabel;
		const message =
			banner?.body &&
			banner?.body
				// eslint-disable-next-line no-template-curly-in-string
				.replace("${firstName}", firstName)
				.replace(/\[\[/gi, "<")
				.replace(/\]\]/gi, ">");
		firstName && message && setBannerMessage({ message, closeAriaLabel });
	};

	const higherAffiliationsReducer = (
		higherAffiliationLevelIndex,
		{ level, affiliationType }
	) => {
		if (affiliationType !== AFFILIATION_TYPE_NAME)
			return higherAffiliationLevelIndex;

		const secondaryMessageIndex = secondaryMessage?.descriptions.findIndex(
			({ id }) => id === level
		);

		return secondaryMessageIndex < higherAffiliationLevelIndex
			? secondaryMessageIndex
			: higherAffiliationLevelIndex;
	};

	const closeBannerHandler = () => {
		setCookie(dismissedCookieName, "true");
		setBannerMessage(null);
		setDismissed(true);
	};

	useEffect(() => {
		try {
			const dismissedCookie = getCookie(dismissedCookieName);
			const travelAgentCookie = getCookie(travelAgentCookieName);
			dismissedCookie && setDismissed(dismissedCookie === "true");
			travelAgentCookie && setIsTravelAgent(travelAgentCookie);
		} catch (error) {
			console.error(error);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useEffect(() => {
		if (secondaryMessage) {
			const affiliations = user?.affiliations;

			const higherAffiliation = isTravelAgent
				? secondaryMessage?.descriptions.findIndex(
						({ id }) => id === TRAVEL_AGENT
				  )
				: affiliations?.reduce(higherAffiliationsReducer, 100);

			if (higherAffiliation !== undefined) {
				const banner = secondaryMessage?.descriptions[higherAffiliation];
				generateBanner(banner);
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [user, isTravelAgent, secondaryMessage]);

	if (dismissed || !bannerMessage || !user) return null;

	return (
		<div className="syndicated-secondary-message">
			<div className="syndicated-secondary-message__content">
				<div
					className="syndicated-secondary-message__message guestSensitive"
					dangerouslySetInnerHTML={{ __html: bannerMessage.message }}
				/>
				{bannerMessage.closeAriaLabel && (
					<button
						className="syndicated-secondary-message__close"
						onClick={closeBannerHandler}
						aria-label={bannerMessage.closeAriaLabel}
						style={{
							backgroundImage: `url(${getCdn(
								true
							)}/icons/secondary-message/close.svg)`,
						}}
					/>
				)}
			</div>
		</div>
	);
};

export default SecondaryMessage;
