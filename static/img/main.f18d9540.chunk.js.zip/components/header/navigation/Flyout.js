import Fairy from "components/shared/Fairy";
import { useContext } from "react";
import { Context } from "Context";

const flyoutMainClass = "syndicated-flyout";
const sectionHelp = "help";

const Flyout = ({
	right = false,
	column = false,
	name = "",
	store,
	children,
}) => {
	let classes = "";
	if (name) classes += ` ${flyoutMainClass}--${name}`;
	if (right) classes += ` ${flyoutMainClass}--right`;
	if (column) classes += ` ${flyoutMainClass}--column`;
	if (store) classes += ` ${flyoutMainClass}--store`;

	return <div className={`${flyoutMainClass}${classes}`}>{children}</div>;
};

const Primary = (props) => {
	const {
		config: { brand },
	} = useContext(Context);
	const { theme = "", name = "", isMobileView = false } = props;
	const mainClass = `${flyoutMainClass}__primary`;
	const themeModifier = theme ? `${mainClass}--${theme}` : "";
	const nameModifier = name ? `${mainClass}--${name}` : "";
	const addFairyComponent =
		brand === "wdw" && name === sectionHelp && !isMobileView;

	return (
		<div className={`${mainClass} ${themeModifier} ${nameModifier}`}>
			{addFairyComponent && <Fairy />}
			{props.children}
		</div>
	);
};

const Secondary = (props) => {
	const { theme = "", name = "" } = props;

	const mainClass = `${flyoutMainClass}__secondary`;
	const themeModifier = theme ? `${mainClass}--${theme}` : "";
	const nameModifier = name ? `${mainClass}--${name}` : "";

	return (
		<div className={`${mainClass} ${themeModifier} ${nameModifier}`}>
			{props.children}
		</div>
	);
};

Flyout.Primary = Primary;
Flyout.Secondary = Secondary;
export default Flyout;
