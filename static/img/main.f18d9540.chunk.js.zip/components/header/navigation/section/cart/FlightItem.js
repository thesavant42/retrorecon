import { Fragment } from "react";
import Title from "components/shared/Title";

const Flight = ({ content }) => {
	const mainClass = "syndicated-section__content__item";
	return (
		<div className={`${mainClass} ${mainClass}--flight`}>
			{content.arrival && content.departure ? (
				<Fragment>
					<Title name="arrival" subTitle={content.arrival} />
					<Title name="departure" subTitle={content.departure} />
				</Fragment>
			) : (
				<Title name="flight" subTitle={content} />
			)}
		</div>
	);
};

export default Flight;
