import React from "react";

const Message = ({ label, content }) => {
	const mainClass = "syndicated-section__content__message";
	return (
		<div className={`${mainClass}`}>
			<p className={`${mainClass}__title`}>{label}</p>
			<p
				className={`${mainClass}__content`}
				dangerouslySetInnerHTML={{
					__html: content,
				}}
			/>
		</div>
	);
};

export default Message;
