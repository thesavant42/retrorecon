import React from "react";
import Title from "components/shared/Title";

const RoomItem = ({ partyMix = "", reservationDates = "", content = "" }) => {
	const mainClass = "syndicated-section__content__item";

	return (
		<div className={`${mainClass} ${mainClass}--room`}>
			<Title name="dates" subTitle={reservationDates} />
			<Title name="party-mix" subTitle={partyMix} />
			<Title name="content" subTitle={content} />
		</div>
	);
};

export default RoomItem;
