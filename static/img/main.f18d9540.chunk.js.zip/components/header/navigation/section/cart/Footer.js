import { useState, useContext } from "react";
import Link from "components/shared/Link";
import Button from "components/shared/Button";
import Icon from "components/shared/Icon";
import Profile from "components/header/profile/Profile";
import Container from "components/shared/Container";
import Separator from "components/shared/Separator";
import { Context } from "Context";

const mainClass = "syndicated-section__content__footer";
const currencyChangeSectionClass = `${mainClass}__currency-change`;

const Footer = ({
	brand,
	price = {},
	buttons: { checkOut, viewCartCheckOut, viewDetails } = {},
	showLink = true,
	showButtons = true,
	currencyChangeDetail = null,
	startOver = null,
	emptyCart = null,
}) => {
	const {
		config: { store },
		headerData: {
			interstitial: { interstitialEmptyCart },
		},
		setModal,
	} = useContext(Context);

	const { label = "", total = "", currency = "", symbol = "" } = price;

	const buttonLink = (showLink ? checkOut : viewCartCheckOut) || {};

	const [showDisclaimer, setShowDisclaimer] = useState(false);

	const handleDisclaimerToggle = (e) => {
		e.preventDefault();
		setShowDisclaimer(!showDisclaimer);
	};

	const getEmptyCartRedirectUrl = () => {
		const emptyCartUrl = interstitialEmptyCart?.webLink?.href;
		return emptyCartUrl
			? `${window.location.origin}${emptyCartUrl}${store}/`
			: "";
	};

	return (
		<div className={`${mainClass} ${mainClass}--${brand}`}>
			<div className={`${mainClass}__total ${mainClass}__total--${brand}`}>
				<span
					className={`${mainClass}__total__label ${mainClass}__total__label--${brand}`}
				>
					{label}
				</span>
				<span className={`${mainClass}__total__content`}>
					<span
						className={`${mainClass}__total__content__value ${mainClass}__total__content__value--${brand}`}
					>{`${symbol}${total}`}</span>
					{currency && (
						<span
							className={`${mainClass}__total__content__currency ${mainClass}__total__content__currency--${brand}`}
						>
							{currency}
						</span>
					)}
				</span>
			</div>
			{currencyChangeDetail && (
				<div className={currencyChangeSectionClass}>
					<p className={`${currencyChangeSectionClass}--currency-charged`}>
						{currencyChangeDetail.currencyCharged}
					</p>
					<p className={`${currencyChangeSectionClass}--estimated-cost`}>
						{currencyChangeDetail.estimatedCost}
					</p>
					<p className={`${currencyChangeSectionClass}__total`}>
						<span>{currencyChangeDetail.total}</span>
						<span className={`${currencyChangeSectionClass}__total__currency`}>
							{currencyChangeDetail.currency}
						</span>
					</p>
					<div className={`${currencyChangeSectionClass}__disclaimer`}>
						<button onClick={handleDisclaimerToggle}>
							{currencyChangeDetail.disclaimerTitle}
							<Icon
								icon={"norgie-opened"}
								className={showDisclaimer ? "syndicated-icon--rotate-180" : ""}
							/>
						</button>
						{showDisclaimer && <p>{currencyChangeDetail.disclaimerText}</p>}
					</div>
				</div>
			)}
			{showButtons && (
				<div className={`${mainClass}__button ${mainClass}__button--${brand}`}>
					{showLink && (
						<Link
							{...viewDetails}
							className={`${mainClass}__button--view-details`}
						/>
					)}
					<Profile
						oneId
						notLoggedIn
						redirectOnLogin
						target={buttonLink.target}
						renderComponent={(handleClick) => (
							<Button
								className={`${mainClass}__button--check-out`}
								link={true}
								linkContent={{ ...buttonLink, handleClick }}
							/>
						)}
					/>
				</div>
			)}
			{store && emptyCart && (
				<div className={`${mainClass}__empty-cart`}>
					<Separator />
					<Container direction="row">
						<span>{startOver}</span>
						<Button
							title={emptyCart}
							secondary={true}
							onClick={() =>
								setModal({
									title: interstitialEmptyCart?.title,
									content: interstitialEmptyCart?.description,
									primaryButton: interstitialEmptyCart?.primaryButton,
									secondaryButton: interstitialEmptyCart?.secondaryButton,
									href: getEmptyCartRedirectUrl(),
									target: interstitialEmptyCart?.webLink?.target,
								})
							}
						/>
					</Container>
				</div>
			)}
		</div>
	);
};

export default Footer;
