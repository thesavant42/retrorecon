import { Fragment, useContext } from "react";
import Icon from "components/shared/Icon";
import Image from "components/shared/Image";
import Title from "components/shared/Title";
import Link from "components/shared/Link";
import Profile from "components/header/profile/Profile";
import Schedule from "components/header/navigation/section/schedule/Schedule";
import MoreParkHours from "components/header/navigation/section/schedule/MoreParkHours";
import { Context } from "Context";

const mainClass = "syndicated-link-groups";
const mainListClass = `${mainClass}__list`;
const mainLinkClass = `${mainClass}__link`;
const mainTitleClass = `${mainClass}__title`;
const moreParkHoursId = "moreParkHours";
const authenticationOptionsId = "authenticationOptions";
const targetOneId = "ngeGate";
const defaultAffiliationId = "default";
// const standardAffiliationId = "STD_GST";

const LinkGroup = ({
	id,
	text,
	webLinkList,
	descriptions,
	modules,
	profile,
	isMobileView,
}) => {
	const {
		profileData: { affiliations },
	} = useContext(Context);

	const titleClass = `${mainTitleClass}${
		id ? ` ${mainTitleClass}--${id}` : ""
	}`;

	const renderDescription = ({ icon, link, title, description, image }) => {
		return (
			<Fragment>
				{image && <Image image={image} name={id} />}
				{icon && <Icon icon={icon} />}
				<Title
					className={titleClass}
					title={title || link?.title}
					subTitle={description}
					name={id}
				/>
			</Fragment>
		);
	};

	const renderLinkGroup = (
		descriptions,
		isDescription = false,
		isPromo = false,
		linkGroupId = ""
	) => {
		const hasParkHoursIcon = descriptions.find(
			(description) =>
				(description.id === moreParkHoursId || description.parkHour) &&
				description.icon
		);
		let affiliationsToUse = [defaultAffiliationId];
		if (isPromo) {
			if (
				affiliations.length &&
				descriptions.filter(({ id }) => affiliations.includes(id)).length
			) {
				affiliationsToUse = [...affiliations];
				// Validate with Zinger the value for the default affiliation
				// if (affiliations.includes(standardAffiliationId)) {
				// 	affiliationsToUse.push(defaultAffiliationId);
				// }
			}
		}

		let groupClass = mainListClass;
		if (id) groupClass += ` ${mainListClass}--${id}`;
		if (isPromo && isDescription) groupClass += ` ${mainListClass}--promo`;
		if (linkGroupId) groupClass += ` ${mainListClass}--${linkGroupId}`;

		const linkContent = (link, description) => (
			<Fragment>
				{isDescription ? (
					renderDescription(description)
				) : (
					<Title title={link.title} noWrap subTitle={link.subTitle} name={id} />
				)}
				{isPromo && <Icon icon="next" />}
			</Fragment>
		);

		const renderDescriptions = descriptions.map((description, index) => {
			if (isPromo && !affiliationsToUse.includes(description.id)) {
				return null;
			}

			if (description.id === authenticationOptionsId) {
				groupClass += ` ${mainListClass}--${authenticationOptionsId}`;
			}

			let listItemClass = `${mainListClass}__item`;
			if (description.id)
				listItemClass += ` ${listItemClass}--${description.id}`;

			const link = isDescription ? description.link : description;

			let linkClass = mainLinkClass;
			if (link) {
				if (id) linkClass += ` ${linkClass}--${id}`;
				if (
					description.id === moreParkHoursId ||
					(isDescription &&
						!description.title &&
						!description.image &&
						!description.icon)
				)
					linkClass += ` ${mainLinkClass}--empty`;
				if (
					["entertainmentsSchedule", "parkCalendar"].includes(description.id) &&
					hasParkHoursIcon
				)
					linkClass += ` ${mainLinkClass}--with-icons`;
			}

			if (description.id === moreParkHoursId) {
				return (
					<MoreParkHours
						description={description}
						linkClass={linkClass}
						listItemClass={listItemClass}
						name={id}
						titleClass={titleClass}
						key={index}
					/>
				);
			}

			if (description.parkHour) {
				return (
					<Schedule
						description={description}
						link={link}
						listItemClass={listItemClass}
						linkClass={linkClass}
						key={index}
					/>
				);
			}

			return (
				<li key={index} className={listItemClass}>
					{link ? (
						link?.target === targetOneId ? (
							<Profile
								oneId
								target={link.target}
								renderComponent={(handleClick) => (
									<Link
										{...link}
										handleClick={handleClick}
										className={linkClass}
									>
										{linkContent(link, description)}
									</Link>
								)}
							/>
						) : (
							<Link {...link} className={linkClass}>
								{linkContent(link, description)}
							</Link>
						)
					) : (
						renderDescription(description)
					)}
					{description.id === authenticationOptionsId && (
						<Profile userStatusLinks />
					)}
				</li>
			);
		});

		return <ul className={groupClass}>{renderDescriptions}</ul>;
	};

	return (
		<div className="syndicated-link-groups">
			{profile && !isMobileView && <Profile card />}
			{text && (
				<div
					className={`syndicated-link-groups__text ${
						id ? `syndicated-link-groups__text--${id}` : ""
					}`}
					dangerouslySetInnerHTML={{ __html: text }}
				/>
			)}
			{webLinkList && renderLinkGroup(webLinkList)}
			{modules?.map(
				({ webLinkList, title, descriptions, isPromo = false, id }, index) => (
					<Fragment key={index}>
						{title && (
							<div
								className={`${titleClass}${
									id ? ` ${mainTitleClass}--${id}` : ""
								}`}
								dangerouslySetInnerHTML={{ __html: title }}
							/>
						)}
						{webLinkList && renderLinkGroup(webLinkList, false, false, id)}
						{descriptions && renderLinkGroup(descriptions, true, isPromo)}
					</Fragment>
				)
			)}
			{descriptions && renderLinkGroup(descriptions, true)}
		</div>
	);
};

export default LinkGroup;
