import Flyout from "../Flyout";
import useCheckMediaQuery from "hooks/useCheckMediaQuery";
import SectionTitle from "components/header/navigation/section/Title";
import LinkGroup from "./LinkGroup";
import { useRef } from "react";
import useKeyboardNav from "hooks/useKeyboardNav";
import { mobileMediaQuery, sectionsConfiguration } from "config.json";

const Section = ({
	id,
	title,
	icon,
	link,
	primary,
	secondary,
	showFlyout = true,
	collapse,
	accessibiltyText,
	setCollapsedSection,
	isMenuActive,
	setIsMenuActive,
	store,
	brand,
}) => {
	const isMobileView = useCheckMediaQuery(mobileMediaQuery);
	const sectionRef = useRef(null);
	const {
		onFocus,
		handleKeyDown,
		handleOnFocus,
		handleOnBlur,
	} = useKeyboardNav(sectionRef, isMenuActive, setIsMenuActive);

	const mainClass = "syndicated-section";
	let classes = mainClass;
	if (id) classes += ` ${mainClass}--${id}`;
	if (brand) classes += ` ${mainClass}--${brand}`;
	if (isMobileView && collapse) classes += ` ${mainClass}--open`;
	if (!showFlyout) classes += ` ${mainClass}--no-flyout`;
	if (isMenuActive && onFocus) classes += ` ${mainClass}--onfocus`;
	if (store) classes += ` ${mainClass}--store`;

	const handleCollapse = (e) => {
		if (isMobileView) {
			e.preventDefault();
			setCollapsedSection((currentCollapsedSection) =>
				currentCollapsedSection === id ? "" : id
			);
		}
	};

	if (!title) return null;

	return (
		<div
			className={classes}
			tabIndex={-1}
			ref={sectionRef}
			onKeyDown={handleKeyDown}
			onFocus={handleOnFocus}
			onBlur={handleOnBlur}
		>
			<SectionTitle
				collapse={collapse}
				link={{
					...link,
					handleClick: showFlyout ? handleCollapse : null,
				}}
				icon={icon}
				title={title}
				name={id}
				isMobileView={isMobileView}
				accessibiltyText={accessibiltyText}
			/>
			{showFlyout && collapse && (
				<Flyout
					right={sectionsConfiguration.right.includes(id)}
					column={sectionsConfiguration.column.includes(id)}
					name={id}
					store={store}
				>
					{primary && (
						<Flyout.Primary name={id} isMobileView={isMobileView}>
							<div
								className={`${mainClass}__content ${mainClass}__content--${id}`}
							>
								<LinkGroup
									{...primary}
									id={id}
									mainClass={`${mainClass}__content--${id}__primary`}
									isMobileView={isMobileView}
								/>
							</div>
						</Flyout.Primary>
					)}
					{secondary && (
						<Flyout.Secondary name={id} theme={"blue"}>
							<div
								className={`${mainClass}__content ${mainClass}__content--${id}`}
							>
								<LinkGroup
									{...secondary}
									id={id}
									mainClass={`${mainClass}__content--${id}__secondary`}
								/>
							</div>
						</Flyout.Secondary>
					)}
				</Flyout>
			)}
		</div>
	);
};

export default Section;
