import { useContext } from "react";
import { Context } from "Context";
import Icon from "components/shared/Icon";
import Link from "components/shared/Link";
import Title from "components/shared/Title";
import { mapString } from "utils";
import { getCurrentDateInSelectedLocale } from "utils/date";
import { defaultParkHoursTimeZone, brands } from "config.json";

const moreParkHoursClass = `syndicated-link-groups__list__item--moreParkHours`;

const MoreParkHours = ({
	name,
	description,
	listItemClass,
	titleClass,
	linkClass,
}) => {
	const {
		config: { locale, brand },
	} = useContext(Context);
	const parkHoursTimeZone =
		brands?.[brand]?.defaultParkHoursTimeZone || defaultParkHoursTimeZone;

	return (
		<li className={listItemClass}>
			<div className={`${moreParkHoursClass}__container`}>
				<Icon icon={description?.icon} />
				<div
					className={`${moreParkHoursClass}__container__content ${moreParkHoursClass}__container__content--${brand}`}
				>
					<Title
						className={titleClass}
						title={mapString(description?.title, "")}
						subTitle={`<span class="${moreParkHoursClass}__container__content__date ${moreParkHoursClass}__container__content__date--${brand}">${getCurrentDateInSelectedLocale(
							parkHoursTimeZone,
							"full",
							locale,
							true
						)}</span>`}
						name={name}
					/>
					{description?.link && (
						<Link
							{...description.link}
							className={`${linkClass} ${moreParkHoursClass}__container__content__link ${moreParkHoursClass}__container__content__link--${brand}`}
						>
							<Title title={description.link.title} noWrap name={name} />
						</Link>
					)}
				</div>
			</div>
		</li>
	);
};

export default MoreParkHours;
