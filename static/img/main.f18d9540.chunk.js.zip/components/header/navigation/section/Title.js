import React from "react";
import Link from "components/shared/Link";
import Icon from "components/shared/Icon";
import { Fragment } from "react";
import Profile from "components/header/profile/Profile";
import AccessibleText from "components/shared/AccessibleText";
import { getCdn } from "utils";

const SectionTitle = (props) => {
	const {
		collapse,
		link,
		name,
		icon = "",
		title = "",
		isMobileView = false,
		accessibiltyText,
	} = props;
	const mainClass = "syndicated-section-title";
	const targetOneId = "ngeGate";
	const inlineStyles = {};

	if (name === "mdx") {
		inlineStyles.backgroundImage = `url(${getCdn(true)}/icons/header/mdx.svg)`;
	}

	const linkContent = (
		<Fragment>
			<Icon
				icon={"norgie-closed"}
				rotate={collapse}
				className={`${mainClass}__link__icon ${mainClass}__link__icon--norgie-closed`}
			/>
			<Icon
				icon={icon}
				className={`${mainClass}__link__icon ${mainClass}__link__icon--${name}`}
			/>
			<div
				className={`${mainClass}__link__category--${name}`}
				dangerouslySetInnerHTML={{ __html: title }}
				style={inlineStyles}
			/>
			{accessibiltyText && <AccessibleText>{accessibiltyText}</AccessibleText>}
		</Fragment>
	);

	return (
		<div className={`${mainClass} ${mainClass}--${name}`}>
			{!isMobileView && link?.target === targetOneId ? (
				<Profile
					oneId
					notLoggedIn
					target={link.target}
					renderComponent={(handleClick) => (
						<Link
							{...link}
							handleClick={handleClick}
							className={`${mainClass}__link`}
							role="menuitem"
						>
							{linkContent}
						</Link>
					)}
				/>
			) : (
				<Link {...link} className={`${mainClass}__link`} role="menuitem">
					{linkContent}
				</Link>
			)}
		</div>
	);
};

export default SectionTitle;
