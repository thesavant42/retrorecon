import { Fragment, useContext, useEffect, useState } from "react";
import Link from "components/shared/Link";
import Separator from "components/shared/Separator";
import Icon from "components/shared/Icon";
import { Context } from "Context";
import Button from "components/shared/Button";
import useCheckMediaQuery from "hooks/useCheckMediaQuery";
import { mobileMediaQuery } from "config.json";
import {
	processLanguageSelectorUrl,
	getLanguageCookies,
	setLanguageCookies,
} from "utils/language";

const LanguageSelector = () => {
	const {
		headerData: { languageSelector },
		config: { allowedLocales, brand, locale },
		setModal,
	} = useContext(Context);

	const isMobileView = useCheckMediaQuery(mobileMediaQuery);

	const [selection, setSelection] = useState("");

	const handleLanguageClick = (e, url) => {
		if (url.match(/^http/) || !languageSelector?.cookiesToSet) return;
		let locale, preferredLanguage, localeCurrency;
		e.preventDefault();
		preferredLanguage = url.replaceAll("/", "");
		let [language, region] = preferredLanguage.split("-");
		if (region) {
			region = region.toUpperCase();
		}
		locale = `${language}${region ? `_${region}` : ""}`;
		if (languageSelector?.localeToCurrency) {
			localeCurrency = languageSelector.localeToCurrency?.[locale];
		}
		setLanguageCookies(
			getLanguageCookies(
				languageSelector.cookiesToSet,
				locale,
				localeCurrency,
				preferredLanguage
			)
		);
		window.location.reload();
	};

	const renderLanguages = (languages) => {
		let localesToDisplay = null;
		if (allowedLocales) {
			localesToDisplay = allowedLocales.split(",");
		}
		return languages ? (
			<div className="syndicated-language-selector__container__content">
				{languages?.map((link, key) => {
					if (localesToDisplay) {
						let currentLocale = null;
						if (link?.href[0] === "/") {
							currentLocale = link.href.split("/")[1]?.toLowerCase();
						}
						if (currentLocale && !allowedLocales.includes(currentLocale)) {
							return null;
						}
					}

					return (
						<Link
							{...link}
							href={processLanguageSelectorUrl(link?.href, brand)}
							handleClick={(event) => handleLanguageClick(event, link?.href)}
							byPassBasePath={true}
							key={key}
						/>
					);
				})}
			</div>
		) : null;
	};

	useEffect(() => {
		const processLocale = (value = "") => {
			return value
				?.replace(/\//g, "")
				.toLowerCase()
				.replace("-", "")
				.replace("_", "");
		};
		let selectedLocale = null;
		if (locale && languageSelector) {
			const newLocale = processLocale(locale);
			for (let key of ["primary", "secondary"]) {
				const searchedLocale = languageSelector[key]?.find(
					({ href }) => newLocale === processLocale(href)
				);
				if (searchedLocale) {
					selectedLocale = searchedLocale;
					break;
				}
			}
		}
		setSelection(selectedLocale?.title || "");
	}, [languageSelector, locale]);

	const modalContent = () => {
		return (
			<Fragment>
				<div className="syndicated-language-selector__container">
					{renderLanguages(languageSelector.primary)}
					{languageSelector.primary && languageSelector.secondary && (
						<Separator vertical />
					)}
					{renderLanguages(languageSelector.secondary)}
				</div>
				<div className="syndicated-language-selector__footer">
					<Separator section="language" />
					<Button
						accessibleText={languageSelector.button?.accessibilityText}
						className="syndicated-language-selector__close"
						onClick={() => setModal(false)}
						secondary={!isMobileView}
						title={languageSelector.button?.title}
					/>
				</div>
			</Fragment>
		);
	};

	if (!languageSelector) return null;

	return (
		<div className="syndicated-language-selector">
			<button
				aria-label={selection}
				className="syndicated-language-selector__open"
				onClick={() => setModal({ content: modalContent() })}
			>
				<Icon icon={languageSelector.icon || "global-languages"} />
				<span>{selection}</span>
			</button>
		</div>
	);
};

export default LanguageSelector;
