import React, { useState, useEffect, useContext } from "react";
import Container from "components/shared/Container";
import useSessionStorage from "hooks/useSessionStorage";
import useFetch from "hooks/useFetch";
import { content } from "config.json";
import { getCdn, objectIsEmpty } from "utils";
import { getCookie, setCookie } from "utils/cookie";
import { trackLink } from "utils/analyticsFramework";
import { Context } from "Context";

const iconsPath = `${getCdn(true)}/icons/message-center/`;

function MessageCenter() {
	const {
		config: { brand },
	} = useContext(Context);

	const disneySiteRegExp = /(disney)\w+/;
	const messageIdPrefix = "async-global-message-";
	const localeDetectionRegExp = /^\/[\w]{2}(-|_)[\w]{2}\/|^\/(\w{2})\//;

	const [storageViewedMessages, setStorageViewedMessages] = useSessionStorage(
		"messageCenterViewed",
		[]
	);
	const [toggle, setToggle] = useState(true);
	const [showViewed, setShowViewed] = useState(false);
	const [messagesData, setMessagesData] = useState([]);
	const [configuration, setConfiguration] = useState({});
	const [messagesViewed, setMessagesViewed] = useState([]);
	const [messages, setMessages] = useState([]);

	const { response } = useFetch(content.apiUrl.messageCenter);

	useEffect(() => {
		const isInSite = document.referrer.match(disneySiteRegExp);
		!isInSite && setStorageViewedMessages([]);
		response?.descriptions?.length &&
			setConfiguration(response.descriptions?.[0]?.sections);
		response?.alerts && setMessagesData(processMessages(response.alerts));
		//eslint-disable-next-line react-hooks/exhaustive-deps
	}, [response]);

	useEffect(() => {
		const viewed = messagesData.filter((message) => {
			return message.viewed;
		});

		const notViewed = messagesData.filter((message) => {
			return !message.viewed;
		});
		setMessagesViewed(viewed);
		setMessages(notViewed);
	}, [messagesData]);

	useEffect(() => {
		setToggle(!!messages.length);
		setShowViewed(!(!messages.length && messagesViewed.length));
	}, [messagesViewed, messages]);

	if (objectIsEmpty(configuration)) {
		return null;
	}

	function processMessages(messages) {
		const daysToExpire = 30;
		const path = window.location.pathname.match(localeDetectionRegExp)
			? `/${window.location.pathname}`.replace(localeDetectionRegExp, "")
			: window.location.pathname;

		return messages
			.filter((message) => {
				const id = `${messageIdPrefix}${message.type}-${message.content?.length}`.replace(
					//eslint-disable-next-line no-useless-escape
					/[^A-Za-z0-9\-]/g,
					""
				);
				message.id = id;
				return hasToDisplay(message, path);
			})
			.map((message) => {
				if (message.type === "terms") message.expiration = daysToExpire;
				message.viewed = storageViewedMessages?.indexOf(message.id) !== -1;
				message.type = message.type?.toLowerCase().replace(/\s/g, "_");
				message.content =
					message.content &&
					message.content !== "&nbsp;" &&
					message.content?.trim() !== ""
						? message.content
						: false;
				return message;
			});
	}

	const removeDuplicates = (messageIds) => {
		return messageIds.filter((id, index, result) => {
			return result.indexOf(id) === index;
		});
	};

	const removeIdsFromViewed = (messageIds) => {
		return messageIds.length
			? storageViewedMessages.filter(
					(viewed) => messageIds.indexOf(viewed) === -1
			  )
			: [];
	};

	const toggleMessagesCenterHandler = () => {
		const messagesIds = messages.map(({ id }) => id);
		const messagesViewedIds = messagesViewed.map(({ id }) => id);
		if (toggle) {
			setStorageViewedMessages(
				removeDuplicates(
					storageViewedMessages.concat(messagesIds).concat(messagesViewedIds)
				)
			);
		} else {
			setStorageViewedMessages(removeIdsFromViewed(messagesViewedIds));
		}
		setToggle((prevState) => !prevState);
	};

	const toggleMessagesViewedHandler = () => {
		const messagesViewedIds = messagesViewed.map(({ id }) => id);
		setStorageViewedMessages(removeIdsFromViewed(messagesViewedIds));
		setShowViewed((prevState) => !prevState);
	};

	const closeMessageHandler = (id) => {
		if (id && brand) {
			const updatedModel = {
				linkId: `${brand.toUpperCase()}_${id}_Close`,
			};
			trackLink(updatedModel, "ViewModal");
		}
		setMessagesData(messagesData.filter((message) => message.id !== id));
	};

	const renderMessage = (message, index) => (
		<Message
			data={message}
			key={message.id}
			configuration={configuration}
			closeMessageHandler={closeMessageHandler}
		/>
	);

	function hasToDisplay(message, path) {
		const exclude = message.exclude || [];
		const cookieValue = getCookie(message.id);

		const excluded = exclude.some((rule) =>
			path.match(`^${rule.replace("*", ".*")}$`)
		);
		return (
			!excluded &&
			message.pages?.some(
				(rule) => !cookieValue && path.match(`^${rule.replace("*", ".*")}$`)
			)
		);
	}

	return (
		messagesData.length > 0 && (
			<div className="syndicated-message-center" data-nosnippet>
				<div className="syndicated-message-center__header">
					<Container direction="row">
						<div
							className="syndicated-message-center__header__icon"
							aria-hidden="true"
							style={{
								backgroundImage: `url(${iconsPath}header.svg)`,
							}}
						>
							i
						</div>
						<div className="syndicated-message-center__header__title">
							{configuration.title}
						</div>
						<button
							className="syndicated-message-center__header__toggle"
							tabIndex="0"
							onClick={toggleMessagesCenterHandler}
						>
							{toggle ? configuration.viewLessText : configuration.readMoreText}
						</button>
					</Container>
				</div>
				{toggle && (
					<div className="syndicated-message-center__content">
						<Container>
							{showViewed && !!messagesViewed.length && (
								<div className="syndicated-message-center__viewed-toggle-container">
									<button
										className="syndicated-message-center__viewed-toggle"
										onClick={toggleMessagesViewedHandler}
									>
										{(messagesViewed.length > 1
											? configuration.viewedMessagesPlural || ""
											: configuration.viewedMessagesSingular || ""
										).replace("%s", messagesViewed.length)}
									</button>
								</div>
							)}
							{!showViewed && messagesViewed.map(renderMessage)}
							{messages.map(renderMessage)}
						</Container>
					</div>
				)}
			</div>
		)
	);
}

const Message = (props) => {
	const daysOfOneYear = 365;
	const {
		configuration,
		closeMessageHandler,
		data: { type, title, dismissible, content, id, expiration = daysOfOneYear },
	} = props;

	const [display, setDisplay] = useState(true);

	const getBackgroundIcon = (icon) => {
		if (["crisis", "capacity"].includes(icon)) {
			icon = "purple-alert";
		} else if (icon === "health_advisory") {
			icon = "yellow-alert";
		}

		return {
			backgroundImage: `url("${iconsPath}${icon}.svg")`,
		};
	};

	const toggleDisplay = () => {
		setCookie(id, true, expiration);
		setDisplay(false);
		closeMessageHandler(id);
	};

	return (
		display && (
			<div className="syndicated-message-center__message">
				<div
					className={`syndicated-message-center__message__icon
				syndicated-message-center__message__icon--${type}`}
					aria-hidden="true"
					style={getBackgroundIcon(type)}
				>
					i
				</div>
				<div className="syndicated-message-center__message__data">
					<div className="syndicated-message-center__message__data__title">
						{title}
					</div>
					{content && (
						<div
							className="syndicated-message-center__message__data__content"
							dangerouslySetInnerHTML={{ __html: content }}
						></div>
					)}
				</div>
				{dismissible && (
					<div
						className="syndicated-message-center__message__close"
						aria-label={configuration.closeText}
						tabIndex="0"
						onClick={toggleDisplay}
						style={{
							backgroundImage: `url(${iconsPath}close.svg)`,
						}}
					>
						x
					</div>
				)}
			</div>
		)
	);
};

export default MessageCenter;
