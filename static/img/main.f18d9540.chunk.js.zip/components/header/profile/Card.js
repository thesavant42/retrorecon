import Link from "components/shared/Link";
import Image from "components/shared/Image";

const Card = ({ username, avatar, content }) => {
	return (
		<Link {...content} className="syndicated-profile__card">
			<Image
				name="avatar"
				image={{
					url: avatar?.url,
					title: avatar?.title || content?.defaultAvatarTitle,
					height: 50,
					width: 50,
				}}
			/>
			<div className="syndicated-profile__card__details">
				<h3 className="syndicated-profile__card__guest guestSensitive">
					{username}
				</h3>
				<h4 className="syndicated-profile__card__label">{content?.title}</h4>
			</div>
		</Link>
	);
};

export default Card;
