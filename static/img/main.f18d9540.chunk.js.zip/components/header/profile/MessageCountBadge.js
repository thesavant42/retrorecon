import useCheckMediaQuery from "hooks/useCheckMediaQuery";
import { mobileMediaQuery } from "config.json";

const MessageCountBadge = (props) => {
	const isMobileView = useCheckMediaQuery(mobileMediaQuery);
	if (!props.counter || !props.action || isMobileView) {
		return null;
	}
	const mainClass = "syndicated-message-badge";
	return (
		<button className={`${mainClass}${"__button"}`} onClick={props.action}>
			<div className={`${mainClass}${"__content"}`}>{props.counter}</div>
		</button>
	);
};
export default MessageCountBadge;
