import { useContext, useEffect, useState, useRef } from "react";
import { Context } from "Context";
import SmartBanner from "./SmartBanner";
import MessageCenter from "./MessageCenter";
import TravelTrade from "./TravelTrade";
import Navigation from "./navigation/Navigation";
import SecondaryMessage from "./SecondaryMessage";
import useFetch from "hooks/useFetch";
import { content, defaultParkHoursTimeZone, brands } from "config.json";
import Loading from "components/shared/Loading";
import { mapString, isTravelAgent } from "utils";
import { getCurrentDateInSelectedLocale } from "utils/date";

const cacheMinutes = 5;
const mainClass = "syndicated-header";

const Header = () => {
	const {
		config,
		headerData,
		setHeaderData,
		setConfig,
		profileData: { userType },
	} = useContext(Context);
	const [headerUrl, setHeaderUrl] = useState("");
	const brandConfig = brands?.[config.brand];
	const parkHoursTimeZone =
		brandConfig?.defaultParkHoursTimeZone || defaultParkHoursTimeZone;
	const isUserTypeRequired = brandConfig?.isUserTypeRequiredForContentRequest;
	const { response, error } = useFetch(headerUrl, {}, cacheMinutes, headerUrl);
	const headerRef = useRef(null);

	let classes = mainClass;
	if (config.position) {
		classes += ` ${mainClass}--${config.position}`;

		if (config.position === "sticky") {
			const parentDiv = document.querySelector(".syndicated-header-parent");
			parentDiv.classList.add("syndicated-header-parent--sticky");
		}
	}

	if (config.store) {
		classes += ` ${mainClass}__store ${mainClass}__store--${config.store}`;
	}

	if (config.theme) {
		classes += ` syndicated-theme--${config.theme}`;
	}

	useEffect(() => {
		if (!isUserTypeRequired || (isUserTypeRequired && userType)) {
			const headerBaseUrl = mapString(
				content.apiUrl.header,
				getCurrentDateInSelectedLocale(parkHoursTimeZone, "ISO", "en-us")
			);
			setHeaderUrl(
				isUserTypeRequired && userType
					? `${headerBaseUrl}&userType=${userType}`
					: headerBaseUrl
			);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [userType, config.brand]);

	useEffect(() => {
		if (response) {
			setHeaderData(response);
			setConfig((config) => ({
				...config,
				...(response.context || {}),
			}));
		} else if (error) {
			setHeaderData({ error: true, loading: false });
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [error, response]);

	return (
		<div className={classes} ref={headerRef}>
			{config.smartBanner && <SmartBanner />}
			{config.travelTrade &&
				(config.store || (isUserTypeRequired && isTravelAgent(userType))) && (
					<TravelTrade />
				)}
			{config.messageCenter && <MessageCenter />}
			{headerData.loading && <Loading />}
			{!headerData.loading && !headerData.error && (
				<Navigation
					headerRef={headerRef}
					showLogo={!config.navigation && !config.chrome}
				/>
			)}
			{config.secondaryMessage && <SecondaryMessage />}
		</div>
	);
};

export default Header;
