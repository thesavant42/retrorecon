import { Fragment, useContext } from "react";
import FooterWrapper from "components/shared/FooterWrapper";
import Link from "components/shared/Link";
import { Context } from "Context";

const Legal = ({ wrap = true }) => {
	const {
		footerData: { legalFooter },
		legalFooterData,
	} = useContext(Context);
	const LegalWrapper = wrap ? FooterWrapper : Fragment;

	return (
		<LegalWrapper>
			<div className="syndicated-legal">
				{(legalFooter || legalFooterData.legalFooter)?.modules?.map(
					(module, index) => (
						<ul
							key={index}
							className={`syndicated-legal__links syndicated-legal__links--${module.id}`}
						>
							{module.webLinkList?.map((link, index) => (
								<li key={index}>
									<Link {...link} />
								</li>
							))}
						</ul>
					)
				)}
				{(legalFooter || legalFooterData.legalFooter)?.descriptions?.map(
					(description, index) => (
						<p
							key={index}
							className="syndicated-legal__copyright-title"
							dangerouslySetInnerHTML={{ __html: description.title }}
						/>
					)
				)}
			</div>
		</LegalWrapper>
	);
};

export default Legal;
