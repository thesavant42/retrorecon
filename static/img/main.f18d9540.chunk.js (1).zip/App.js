import { useContext } from "react";
import Footer from "components/footer/Footer";
import Header from "components/header/Header";
import Legal from "components/legal/Legal";
import MessageCenter from "components/header/MessageCenter";
import Modal from "components/shared/Modal";
import ReactDOM from "react-dom";
import { urlParams, validateParam } from "utils/paramsValidation";
import { Context } from "Context";
const headerComponent = "header";
const messageCenterComponent = "message-center";
const legalComponent = "legal";
const footerComponent = "footer";

const App = () => {
	const {
		config: { header, footer, legal },
	} = useContext(Context);

	const renderComponent = (targetContainer, component) => {
		let targetId = urlParams.get(`${targetContainer}Container`);

		if (!targetId && targetContainer === legalComponent) {
			targetId = urlParams.get(`${footerComponent}Container`);
		}

		const elementToRender = document.getElementById(
			targetId || `syndicated-${targetContainer}`
		);

		if (!elementToRender) return null;

		if (targetContainer === headerComponent) {
			elementToRender.classList.add("syndicated-header-parent");
		}

		return ReactDOM.createPortal(component, elementToRender);
	};

	return (
		<div id="syndicated-root__app">
			{validateParam(messageCenterComponent) &&
				renderComponent(messageCenterComponent, <MessageCenter />)}
			{header && renderComponent(headerComponent, <Header />)}
			{footer && renderComponent(footerComponent, <Footer />)}
			{legal && renderComponent(legalComponent, <Legal />)}
			<Modal />
		</div>
	);
};

export default App;
