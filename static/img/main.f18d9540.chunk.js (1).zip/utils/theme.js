import { getCdn } from "utils";
import { allowedThemes } from "config";

let bodyMutationObserver;

export const loadExternalThemeStyles = (theme) => {
	if (theme && allowedThemes.includes(theme)) {
		const fileName = `${getCdn()}/themes/${theme}.css`;
		if (!document.querySelector('link[href="' + fileName + '"]')) {
			const link = document.createElement("link");

			link.type = "text/css";
			link.rel = "stylesheet";
			link.href = fileName;
			document.head.appendChild(link);
		}
		if (bodyMutationObserver) {
			bodyMutationObserver.disconnect();
		}
	}
};

const findThemeInClassesList = (classes = document.body.classList) => {
	for (let index = 0; index < allowedThemes.length; index++) {
		if (classes.contains(allowedThemes[index])) {
			loadExternalThemeStyles(allowedThemes[index]);
			return true;
		}
	}
	return false;
};

export const extractThemeFromBodyClasses = () => {
	const theme = findThemeInClassesList();
	if (!theme && !bodyMutationObserver) {
		bodyMutationObserver = new MutationObserver(() => {
			findThemeInClassesList();
		});
		bodyMutationObserver.observe(document.body, { attributeFilter: ["class"] });
	}
};
