import config from "config.json";
import { getCookie } from "utils/cookie";
import {
	loadExternalThemeStyles,
	extractThemeFromBodyClasses,
} from "utils/theme";
import {
	getDefaultLocale,
	localeRegExp,
	getDefaultLocaleCookie,
	getDefaultLocaleCookieProperty,
	getGDPRLocale,
} from "utils/language";

let currentScript, urlParams, url;
const brands = {
	disneyland: "dlr",
	disneyworld: "wdw",
	disneycruise: "dcl",
	disneybeachresorts: "beachresorts",
	disneyaulani: "dpr",
	hiltonhead: "hh",
	hongkongdisneyland: "hkdl",
	verobeach: "vb",
};
const storeParam = "store";
const storesStartPath = "reservations";
const routesWithStoresConfiguration = [
	"/header",
	"/footer",
	"/legal",
	"/message-center",
];
const messageCenterId = "message-center";
const messageCenterParam = "messageCenter";
const themeParamId = "theme";

if (process.env.NODE_ENV === "production") {
	currentScript = document.currentScript;
}

const loadTheme = () => {
	const theme = getParam(themeParamId);
	if (theme) {
		loadExternalThemeStyles(theme);
	} else {
		extractThemeFromBodyClasses();
	}
};

const loadAppConfiguration = () => {
	url = new URL(currentScript ? currentScript.src : window.location.href);
	const isMessageCenter = document.getElementById(messageCenterParam);
	if (isMessageCenter) {
		url.searchParams.append(messageCenterId, true);
		url.searchParams.append(messageCenterParam, false);
		url.searchParams.append(`${messageCenterId}Container`, messageCenterParam);
	}
	urlParams = url.searchParams;
	loadTheme();
};

const getParam = (paramName) => {
	return urlParams.get(paramName)?.toLowerCase() || "";
};

const addParam = (name, value) => {
	urlParams.append(name, value);
};

const validateParam = (paramName, defaultValue = false) => {
	const param = getParam(paramName);
	return param ? param === "true" || param === "1" : defaultValue;
};

const validateParamValue = (paramName, valuesArray, defaultIndex = 0) => {
	const param = getParam(paramName);
	return param && valuesArray.includes(param)
		? param
		: valuesArray[defaultIndex];
};

const loadBrandParam = () => {
	const splittedHostname = window.location.hostname.split(".");
	for (const brand in brands) {
		if (splittedHostname.includes(brand)) {
			return brands[brand];
		}
	}
	return validateParamValue("brand", Object.values(brands));
};

const loadLocaleParam = () => {
	const brand = loadBrandParam();
	let locale = getParam("locale") || getDefaultLocale(brand);
	let parsedLocale;
	let cookie = null;

	if (!config.brands[brand].preventReadingLocaleFromCookie) {
		const localeCookieName = getDefaultLocaleCookie(brand);
		cookie =
			getCookie(`${localeCookieName}_aka`) || getCookie(localeCookieName);
	}

	if (cookie) {
		try {
			const cookieJarObj = JSON.parse(decodeURIComponent(cookie));
			const cookieProperty = getDefaultLocaleCookieProperty(brand);
			parsedLocale = cookieJarObj[cookieProperty];
			if (parsedLocale) {
				locale = parsedLocale;
			}
		} catch (error) {
			console.info(`unable to parse the localeCookie_jar`);
		}
	} else {
		parsedLocale = window.location.pathname
			.match(localeRegExp)?.[0]
			.replace(/\//g, "");
		if (parsedLocale) {
			locale = parsedLocale;
		} else {
			parsedLocale = getGDPRLocale(brand);
			if (parsedLocale) {
				locale = parsedLocale;
			}
		}
	}
	const [language, region] = locale.toLowerCase().replace("_", "-").split("-");
	return `${language}${region ? "-" + region : ""}`;
};

const validateParams = (params = []) => {
	let valid = false;
	for (let index = 0; index < params.length && !valid; index++) {
		valid = validateParam(params[index]);
	}
	return valid;
};

const validateAndAddStoreParam = (url) => {
	if (routesWithStoresConfiguration.some((key) => url.href.includes(key))) {
		const store = getParam(storeParam);
		if (store) {
			url.searchParams.append(storeParam, store);
		} else {
			const pathname = window.location.pathname;
			const pathnameParts = pathname.split("/");
			const storesStartIndex = pathnameParts.findIndex(
				(subpath) => subpath === storesStartPath
			);
			if (storesStartIndex !== -1 && pathnameParts[storesStartIndex + 1]) {
				url.searchParams.append(
					storeParam,
					pathnameParts[storesStartIndex + 1]
				);
			}
		}
	}
};

const loadAffiliations = () => {
	const affiliationParam = getParam("affiliation").toUpperCase();
	return affiliationParam ? affiliationParam.split("-") : [];
};

loadAppConfiguration();

export {
	addParam,
	currentScript,
	getParam,
	loadBrandParam,
	loadLocaleParam,
	loadAffiliations,
	urlParams,
	validateParam,
	validateParams,
	validateParamValue,
	validateAndAddStoreParam,
	loadAppConfiguration,
};
