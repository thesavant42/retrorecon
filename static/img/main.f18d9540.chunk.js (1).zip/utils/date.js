import { brands } from "config.json";
import { loadBrandParam } from "utils/paramsValidation";

const brand = loadBrandParam();

export const getCurrentDateInSelectedLocale = (
	timeZone = "America/New_York",
	dateStyle = "ISO",
	locale = "en-us",
	validateFormat = false
) => {
	const currentDate = new Date();
	const options = { timeZone };
	const isISO = dateStyle === "ISO";
	if (isISO) {
		locale = "en-us";
	} else {
		locale = locale.replace("_", "-").toLowerCase();
		options.dateStyle = dateStyle; // full
		options.calendar = "gregory";
	}

	try {
		const validLocales = Intl.DateTimeFormat.supportedLocalesOf(
			[locale, locale.split("-")[0], "en"],
			{ localeMatcher: "lookup" }
		);
		const validLocale = validLocales[0];
		const formatter = new Intl.DateTimeFormat(validLocale, options);
		let date = formatter.format(currentDate);
		if (isISO) {
			const [month, day, year] = date.split("/");
			return `${year}-${month}-${day}`;
		} else {
			if (validateFormat && brands[brand]?.localesDateFormat) {
				const localeDateFormat = brands[brand]?.localesDateFormat[locale];
				if (localeDateFormat) {
					const dateParts = formatter.formatToParts(currentDate);
					date = "";
					for (let index = 0; index < localeDateFormat.length; index++) {
						const char = localeDateFormat[index];
						if (!["{", "}"].includes(char)) {
							if (dateParts[char]) {
								date += dateParts[char]?.value || "";
							} else {
								date += char;
							}
						}
					}
				}
			}
			return date;
		}
	} catch (error) {
		console.error(error);
		return getCurrentDateInSelectedLocaleFallback(
			currentDate,
			dateStyle,
			locale,
			options
		);
	}
};

export const getCurrentDateInSelectedLocaleFallback = (
	currentDate,
	dateStyle,
	locale,
	options
) => {
	const isISO = dateStyle === "ISO";
	const date = currentDate.toLocaleDateString(locale, options);
	if (isISO) {
		const [month, day, year] = date.split("/");
		return `${year}-${month}-${day}`;
	} else {
		return date;
	}
};
