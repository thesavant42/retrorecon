import { cdn } from "config.json";

const productionEnvironment = "prod";
const latestEnvironment = "latest";
const developmentEnvironment = "development";
const localEnvironment = "localhost";
const hostnamesAllowed = [
	localEnvironment,
	latestEnvironment,
	"stage",
	"lt01",
	productionEnvironment,
];
const syndicatedPathname = "/media/layout/syndicated/";
const helpUiPathname = "/media/layout/help-ui/";
const developmentSubdomains = [
	localEnvironment,
	"versions",
	"pep-local",
	"dev",
];

export const isCdnPage = () => {
	return (
		window.location.pathname.includes(syndicatedPathname) ||
		window.location.pathname.includes(helpUiPathname)
	);
};

export const objectIsEmpty = (object) => !Object.keys(object || {}).length;

export const arrayIsEmpty = (array = []) => array.length === 0;

export const mapString = (target = "", ...args) => {
	let index = -1;
	return target.replace(/{[a-zA-Z0-9._-]+}/gi, () => {
		index++;
		return args[index];
	});
};

export const getEnvironment = () => {
	const { hostname, pathname } = window.location;
	let mainSubdomain = hostname.split(".")[0];

	if (isCdnPage()) {
		mainSubdomain = pathname.split("/")[4];
	}

	if (developmentSubdomains.includes(mainSubdomain))
		return developmentEnvironment;
	else if (hostnamesAllowed.includes(mainSubdomain)) return mainSubdomain;
	else return productionEnvironment;
};

export const elementIsDisplayed = (element) =>
	!!(element?.offsetHeight && element?.offsetWidth);

export const isDevelopmentEnvironment = (
	environment = process?.env?.NODE_ENV
) => {
	return environment === developmentEnvironment;
};

export const getCdn = (isIconsUrl = false) => {
	const baseUrl = cdn.baseUrl;
	const iconsCdn = `${baseUrl}${cdn.assets}`;
	const syndicatedCdn = `${baseUrl}${cdn.syndicated}`;
	let env = getEnvironment();
	if (env === developmentEnvironment) env = latestEnvironment;

	return !isIconsUrl && isDevelopmentEnvironment()
		? "/assets"
		: mapString(
				isIconsUrl ? iconsCdn : syndicatedCdn,
				env === productionEnvironment ? "" : `stage.`,
				env
		  );
};

export const getLoginUrl = (pathname) => {
	const targetUrl = window.location.href.replace(window.location.origin, "");
	return `${pathname}?appRedirect=${targetUrl}`;
};

export const isTravelAgent = (userType) => {
	return (
		userType &&
		!["GUEST", "GUEST_B2B2C", "TRAVEL_AGENT_NOT_SIGNED_IN"].includes(userType)
	);
};
