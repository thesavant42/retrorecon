const getAnalyticsFramework = () => {
	return (
		window.WDPRO && window.WDPRO.Analytics && window.WDPRO.Analytics.Framework
	);
};

const checkInitialization = (ref) => {
	return ref && ref.analyticsModel.length;
};

const trackLink = (model, customEvent) => {
	const ref = getAnalyticsFramework();
	if (checkInitialization(ref)) {
		const updatedModel = Object.assign(model, { trackingType: "customLink" });
		if (customEvent) {
			ref.trackElement(customEvent, updatedModel);
		} else {
			ref.trackElement(updatedModel);
		}
	} else {
		console.error(
			"Something is wrong with Analytics Framework. Check that is correctly configured."
		);
	}
};

export { trackLink };
