import { useEffect, useState } from "react";
import { elementIsDisplayed } from "utils";
import useCheckMediaQuery from "./useCheckMediaQuery";
import { mobileMediaQuery, focusableElements } from "config.json";

const keys = {
	tab: 9,
	enter: 13,
	esc: 27,
	left: 37,
	up: 38,
	right: 39,
	down: 40,
};

const useKeyboardNav = (sectionRef, isMenuActive, setIsMenuActive) => {
	const isMobileView = useCheckMediaQuery(mobileMediaQuery);
	const [onFocus, setOnFocus] = useState(false);
	const [flyoutElements, setFlyoutElements] = useState(null);

	useEffect(() => {
		const elements = sectionRef?.current?.querySelectorAll(focusableElements);
		elements?.length && setFlyoutElements(Array.from(elements));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const moveMenuDown = () => {
		moveMenu(1);
	};

	const moveMenuUp = () => {
		moveMenu(-1);
	};

	const moveMenu = (n) => {
		const currentIndex = flyoutElements?.indexOf(document.activeElement);
		const moveToIndex = currentIndex + n;

		moveToIndex >= 0 &&
			moveToIndex < flyoutElements.length &&
			flyoutElements[moveToIndex]?.focus();

		moveToIndex < 0 && moveSectionLeft();
		moveToIndex >= flyoutElements.length && moveSectionRight();
	};

	const moveSectionLeft = () => {
		const previous = sectionRef?.current?.previousElementSibling;
		const sectionTitle = previous.children[0]?.firstChild;
		const isLastItem = !(previous && elementIsDisplayed(previous));

		!isLastItem && sectionTitle?.focus();
		isLastItem && document.activeElement.blur();
	};

	const moveSectionRight = () => {
		const next = sectionRef?.current?.nextElementSibling;
		const sectionTitle = next?.children[0]?.firstChild;
		const isLastItem = !(next && elementIsDisplayed(next));

		!isLastItem && sectionTitle?.focus();
		isLastItem && document.activeElement.blur();
	};

	const handleOnFocus = (e) => {
		if (isMobileView) return null;
		setOnFocus(true);
	};
	const handleOnBlur = (e) => {
		if (isMobileView) return null;
		setOnFocus(false);
	};

	const handleKeyDown = (e) => {
		if (isMobileView || !Object.values(keys).includes(e.keyCode)) return null;

		// eslint-disable-next-line default-case
		switch (e.keyCode) {
			case keys.enter:
				!isMenuActive && e.preventDefault();
				setIsMenuActive(true);
				break;
			case keys.tab:
				e.preventDefault();
				if (!e.shiftKey) {
					!isMenuActive && moveSectionRight();
					isMenuActive && onFocus && moveMenuDown();
				} else {
					!onFocus && moveSectionLeft();
					onFocus && moveMenuUp();
				}
				break;
			case keys.esc:
				setIsMenuActive(false);
				break;
			case keys.up:
				e.preventDefault();
				!onFocus && moveSectionLeft();
				onFocus && moveMenuUp();
				break;
			case keys.down:
				e.preventDefault();
				!onFocus && moveSectionRight();
				onFocus && moveMenuDown();
				break;
			case keys.left:
				e.preventDefault();
				moveSectionLeft();
				break;
			case keys.right:
				e.preventDefault();
				moveSectionRight();
				break;
		}
	};

	return {
		onFocus,
		handleKeyDown,
		handleOnFocus,
		handleOnBlur,
	};
};

export default useKeyboardNav;
