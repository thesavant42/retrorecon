import { useState, useEffect, useRef } from "react";
import useFetch from "hooks/useFetch";
import {
	getEnvironment,
	isCdnPage,
	mapString,
	getCdn,
	getLoginUrl,
	objectIsEmpty,
	isDevelopmentEnvironment,
} from "utils";
import { getCookie, removeCookie } from "utils/cookie";
import useScript from "hooks/useScript";
import useSessionStorage from "hooks/useSessionStorage";
import useLocalStorage from "hooks/useLocalStorage";
import config from "config.json";

const swidCookieName = "SWID";
const authTokenCookieName = "pep_oauth_token";
const authenticationEvent = "navigationAuth";
const navigationPublishEvent = "navigation";
const syndicatedMakeCartRequest = "syndicatedMakeUserCartRequest";
const syndicatedDismissButton = "syndicatedDismissButton";
const targetOneId = "ngeGate";
const userDataCookieName = "rememberme";
const defaultUserType = "GUEST";
const oneIdPrefix = "oneId-";

const decodeCookieValue = (currentCookieValue) => {
	if (currentCookieValue) {
		try {
			const decodedCookieValue = JSON.parse(
				decodeURIComponent(currentCookieValue)
			);
			if (decodedCookieValue) {
				return decodedCookieValue;
			}
		} catch (error) {
			console.error(error);
		}
	}
	return null;
};

const getCookieValue = (cookieNames = [], baseCookieValue) => {
	let cookieValue = null;
	if (baseCookieValue) {
		cookieValue = decodeCookieValue(baseCookieValue);
	}
	if (!cookieValue) {
		for (let index = 0; index < cookieNames.length; index++) {
			const cookieName = cookieNames[index];
			const currentCookieValue = decodeCookieValue(getCookie(cookieName));
			if (currentCookieValue) {
				return currentCookieValue;
			}
		}
	}
	return cookieValue;
};

const loadGuestAffiliations = (
	brand,
	affiliations = [],
	affiliationsCookie = null,
	geolocationCookie = null
) => {
	let affiliationsToAdd = [];
	try {
		const affiliationsFromCookie = getCookieValue(
			config.cookies.affiliations,
			affiliationsCookie
		);
		if (affiliationsFromCookie) {
			affiliationsToAdd = affiliationsFromCookie?.[brand]?.multiAffls?.length
				? affiliationsFromCookie?.[brand]?.multiAffls
				: affiliationsFromCookie?.[brand]?.storedAffiliations || [];
			affiliations = affiliations.concat(affiliationsToAdd);
		}
	} catch (error) {
		console.error(error);
	}

	try {
		if (
			config.brands[brand].preventReadingGeoCookieWhenLoadedAffiliations &&
			affiliationsToAdd?.length
		) {
			return affiliations;
		}
		const affiliationsFromGeolocation = getCookieValue(
			config.cookies.geolocation,
			geolocationCookie
		);
		if (affiliationsFromGeolocation) {
			const {
				region = "",
				country = "",
				zipCode = "",
			} = affiliationsFromGeolocation;
			if (country) {
				const countryToUse = country
					.toLowerCase()
					.replace(/[+ ]/g, "_")
					.replace(/-/g, "");
				if (config.affiliations.country[countryToUse]) {
					affiliations.push(config.affiliations.country[countryToUse]);
				}
			}
			if (config.affiliations.region[region]) {
				affiliations.push(config.affiliations.region[region]);
			}
			if (zipCode) {
				const zipCodes = zipCode.replace(/-/g, "+").split("+");
				let zipCodeAffiliation = null;
				for (
					let index = 0;
					index < Object.keys(config.affiliations.zipCode).length &&
					!zipCodeAffiliation;
					index++
				) {
					const range = Object.keys(config.affiliations.zipCode)[index].split(
						"_"
					);
					for (
						let zipCodeIndex = 0;
						zipCodeIndex < zipCodes.length && !zipCodeAffiliation;
						zipCodeIndex++
					) {
						if (
							zipCodes[zipCodeIndex] >= range[0] &&
							zipCodes[zipCodeIndex] <= range[1]
						) {
							zipCodeAffiliation =
								config.affiliations.zipCode[
									Object.keys(config.affiliations.zipCode)[index]
								];
						}
					}
				}
				if (zipCodeAffiliation) {
					affiliations.push(zipCodeAffiliation);
				}
			}
		}
	} catch (error) {
		console.error(error);
	}
	return affiliations;
};

const publishNavigationEvent = (eventName) => {
	document.dispatchEvent(
		new CustomEvent(navigationPublishEvent, {
			detail: {
				event: eventName,
			},
		})
	);
};

const useProfile = (
	brand,
	locale,
	profile,
	store,
	affiliationsParam,
	chromeData
) => {
	const getOneIdConfig = () => {
		const oneIdConfig = {
			...config.profile.oneId,
			...brandConfig?.oneId,
			...config.environmentConfiguration?.default?.oneId,
			...config.environmentConfiguration?.[appEnv]?.oneId,
		};
		const oneIdEnv = oneIdConfig?.oneIdEnv;
		const usingOneIdLibrary = oneIdConfig?.usingOneIdLibrary
			? oneIdConfig.usingOneIdLibrary.includes(brand)
			: false;
		const usingOneIdProfileLibrary = oneIdConfig?.usingOneIdProfileLibrary
			? oneIdConfig.usingOneIdProfileLibrary.includes(brand)
			: false;
		const isOneIdSource = usingOneIdLibrary || usingOneIdProfileLibrary;
		const oneIdClientId = isOneIdSource
			? mapString(oneIdConfig?.clientId, oneIdEnv)
			: "";
		const oneIdResponderPage = isOneIdSource
			? mapString(
					isCdnPage()
						? `${window.location.pathname.replace("/index.html", "")}${
								config.environmentConfiguration.development?.oneId
									?.responderPage
						  }`
						: oneIdConfig?.responderPage,
					oneIdEnv,
					oneIdClientId
			  )
			: "";
		const oneIdLibraryUrl = isOneIdSource
			? mapString(oneIdConfig?.oneIdLibrary, oneIdConfig?.oneIdLibraryUrlPrefix)
			: "";
		const oneIdProfileLibraryUrl = usingOneIdProfileLibrary
			? mapString(
					oneIdConfig?.oneIdProfileLibrary,
					oneIdConfig?.oneIdProfileLibraryUrlPrefix
			  )
			: "";
		const disneyIDUrl = isOneIdSource
			? usingOneIdProfileLibrary
				? oneIdProfileLibraryUrl
				: oneIdLibraryUrl
			: "";
		return {
			...oneIdConfig,
			usingOneIdProfileLibrary,
			isOneIdSource,
			oneIdClientId,
			oneIdResponderPage,
			oneIdLibraryUrl,
			disneyIDUrl,
		};
	};

	const readDataFromCookie = () => {
		setTravelAgent({
			readDataFromCookie: true,
		});
	};

	const resetOnActionRedirection = () => {
		if (disneyIdRef.current?.onLoginRedirectTo) {
			disneyIdRef.current.onLoginRedirectTo = null;
		}
		if (disneyIdRef.current?.onLogoutRedirectTo) {
			disneyIdRef.current.onLogoutRedirectTo = null;
		}
	};

	const appEnv = isCdnPage() ? "development" : getEnvironment();
	const brandConfig = config.brands?.[brand];
	const oneIdConfig = getOneIdConfig();
	const isOneIdSource = oneIdConfig?.isOneIdSource || false;

	const [user, setUser] = useState(null);
	const [profileUrl, setProfileUrl] = useState("");
	const [openedOneIdModal, setOpenedOneIdModal] = useState(false);
	const [isLoading, setIsLoading] = useState(profile && isOneIdSource);
	const [affiliations, setAffiliations] = useState([]);
	const [userType, setUserType] = useState(
		brandConfig?.isUserTypeRequiredForContentRequest &&
			window.location.pathname.split("/").includes("trade-public")
			? "TRAVEL_AGENT_NOT_SIGNED_IN"
			: null
	);
	const [loggedInStatusChanged, setLoggedInStatusChanged] = useState(false);
	const [travelAgent, setTravelAgent] = useState(null);
	const [, setStorageMakeCartRequest] = useSessionStorage(
		syndicatedMakeCartRequest,
		true
	);
	const [, setSyndicatedDismissButton] = useLocalStorage(
		syndicatedDismissButton,
		false
	);

	const disneyIdRef = useRef();
	const status = useScript(
		profile && isOneIdSource ? oneIdConfig?.disneyIDUrl : null,
		"head"
	);

	const { response, error } = useFetch(
		profileUrl,
		{
			headers: { swid: user?.swid || "", token: user?.authToken || "" },
		},
		0,
		profileUrl
	);

	useEffect(() => {
		setAffiliations(loadGuestAffiliations(brand, affiliationsParam));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [affiliationsParam]);

	useEffect(() => {
		if (profile && isOneIdSource && status === "ready") {
			initOneId();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [status]);

	useEffect(() => {
		if (!profile || isOneIdSource) return;
		try {
			const authTokenCookie = getCookie(authTokenCookieName);
			const swidCookie = getCookie(swidCookieName);
			let userDataCookie = getCookie(userDataCookieName);

			if (userDataCookie) {
				userDataCookie = JSON.parse(decodeURIComponent(userDataCookie));
			}

			swidCookie &&
				userDataCookie &&
				setUser({
					...user,
					swid: swidCookie,
					authToken: authTokenCookie,
					firstName: userDataCookie?.name || "",
					avatar: {
						...user?.avatar,
						id: userDataCookie?.avatar || "",
					},
				});
		} catch (error) {
			console.error(error);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [profile, loggedInStatusChanged]);

	useEffect(() => {
		if (response) {
			!userType && setUserType(defaultUserType);

			if (
				response[config.cookies.affiliations[0]] ||
				response[config.cookies.geolocation[0]]
			) {
				setAffiliations(
					loadGuestAffiliations(
						brand,
						affiliationsParam,
						response[config.cookies.affiliations[0]],
						response[config.cookies.geolocation[0]]
					)
				);
			}

			if (!objectIsEmpty(response.user)) {
				response.user?.affiliations?.length &&
					setAffiliations(response.user.affiliations);
				setUser({
					...user,
					firstName: response.user?.firstName || user?.firstName,
					lastName: response.user?.lastName,
					avatar: response.user?.avatar,
					affiliations: response.user?.affiliations,
					messages: response.user?.messages,
				});
			}

			if (response.travelAgent?.travelAgency) {
				setTravelAgent(response.travelAgent);
				response.travelAgent?.userType &&
					setUserType(response.travelAgent.userType);
			} else {
				readDataFromCookie();
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [response]);

	useEffect(() => {
		if (error) {
			if (!userType) {
				setUserType(defaultUserType);
			}
			if (user) {
				setUser({
					...user,
					avatar: {
						...user?.avatar,
						url: `${getCdn()}${config.profile.defaultAvatarUrl}`,
					},
				});
			}
			readDataFromCookie();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [error]);

	useEffect(() => {
		const exportAuthLogic = (event) => {
			resetOnActionRedirection();
			const {
				method,
				onLoginRedirectTo = null,
				onLogoutRedirectTo = null,
				preventReloadAndRedirect = false,
				preventExecuteOneIdMethod = false,
			} = event.detail;
			switch (method) {
				case "launchLogin":
					handleLogin(
						event,
						onLoginRedirectTo,
						onLogoutRedirectTo,
						true,
						preventReloadAndRedirect,
						preventExecuteOneIdMethod
					);
					break;
				case "launchReauth":
					if (isOneIdSource) {
						handleClick(
							method,
							onLoginRedirectTo,
							onLogoutRedirectTo,
							preventReloadAndRedirect,
							preventExecuteOneIdMethod
						)(event);
					}
					break;
				case "launchProfile":
					handleProfile(event, onLoginRedirectTo, onLogoutRedirectTo, true);
					break;
				case "logout":
					handleLogout(
						event,
						onLogoutRedirectTo,
						true,
						preventReloadAndRedirect,
						preventExecuteOneIdMethod
					);
					break;
				case "setLoggedInStatus":
					setLoggedInStatusChanged(true);
					if (onLogoutRedirectTo) {
						if (!disneyIdRef.current) {
							disneyIdRef.current = {};
						}
						disneyIdRef.current.onLogoutRedirectTo = onLogoutRedirectTo;
					}
					break;
				default:
					if (isOneIdSource) {
						handleClick(method)(event);
					}
			}
		};

		document.addEventListener(authenticationEvent, exportAuthLogic);

		if (!isLoading && chromeData) {
			publishNavigationEvent(`${authenticationEvent}Listening`);
		}

		return () =>
			document.removeEventListener(authenticationEvent, exportAuthLogic);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [isLoading, chromeData]);

	useEffect(() => {
		const sharedSessionLink = getCookie("SHARED_SESSION_LINK");
		const remembermeCookie = getCookie(userDataCookieName);
		const makeProfileRequestForGettingTAData =
			!remembermeCookie && !user?.swid && sharedSessionLink;
		if (
			user?.swid ||
			brandConfig?.makeProfileRequest ||
			makeProfileRequestForGettingTAData
		) {
			const apiUrl = config.profile.apiUrl;
			const apiUrlParams = [];
			if (user?.avatar?.id) {
				apiUrlParams.push(`avatarId=${user.avatar.id}`);
			}
			if (user?.swid) {
				apiUrlParams.push("isUser=true");
			}
			if (sharedSessionLink) {
				apiUrlParams.push(
					`sharedSessionLink=${encodeURIComponent(sharedSessionLink) || ""}`
				);
			}
			setProfileUrl(
				apiUrlParams.length ? `${apiUrl}?${apiUrlParams.join("&")}` : apiUrl
			);
		} else if (!user?.swid) {
			setProfileUrl("");
		}
		if (!makeProfileRequestForGettingTAData) {
			readDataFromCookie();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [user?.swid, brand, affiliationsParam]);

	const removeCartCookie = () => {
		const cartCookieToRemove = `CART-${brand}${store ? `_${store}` : ""}_jar`;
		if (cartCookieToRemove) {
			removeCookie(cartCookieToRemove.split("=")[0]);
		}
	};

	const initOneId = async () => {
		try {
			let userData = null;
			if (oneIdConfig?.usingOneIdProfileLibrary && window.PEP?.PROFILE_AUTH) {
				await window.PEP.PROFILE_AUTH.init({
					oneIdScriptSrc: oneIdConfig?.oneIdLibraryUrl,
					loadScript: true,
					clientId: oneIdConfig?.oneIdClientId,
					langPref: locale,
					responderPage: oneIdConfig?.oneIdResponderPage,
					cssOverride: oneIdConfig?.cssOverride,
				});
				disneyIdRef.current = window.PEP.PROFILE_AUTH.did;
				const userIsLoggedIn = await disneyIdRef.current.getLoggedInStatus();
				if (userIsLoggedIn) {
					userData = await disneyIdRef.current.getGuest();
					userData?.profile &&
						setUser({
							...user,
							...userData.profile,
							authToken: userData?.token?.access_token,
						});
				}
			} else if (window.DisneyID) {
				disneyIdRef.current = window.DisneyID.get({
					clientId: oneIdConfig?.oneIdClientId,
					responderPage: oneIdConfig?.oneIdResponderPage,
					cssOverride: oneIdConfig?.cssOverride,
				});
				userData = await disneyIdRef.current.init();
				userData?.loggedIn &&
					userData?.guest?.profile &&
					setUser({
						...user,
						...userData.guest.profile,
						authToken: userData.guest.token?.access_token,
					});
			}
			initOneIdEvents();
			publishNavigationEvent(`${oneIdPrefix}init`);
		} catch (error) {
			console.error(error);
		} finally {
			setIsLoading(false);
		}
	};

	const handleRedirectAndReloadLogic = (redirectKey = "Login") => {
		const redirectUrl =
			disneyIdRef.current[`on${redirectKey}RedirectTo`] ||
			disneyIdRef.current[`on${redirectKey}RedirectUrl`];
		if (redirectUrl) {
			window.location.assign(redirectUrl);
		} else {
			window.location.reload();
		}
	};

	const initOneIdEvents = () => {
		disneyIdRef.current.on("login", (data) => {
			if (
				disneyIdRef.current.launchLoginPreventReloadAndRedirect ||
				disneyIdRef.current.launchReauthPreventReloadAndRedirect
			) {
				data?.profile &&
					setUser({ ...data.profile, authToken: data.token?.access_token });
				publishNavigationEvent(`${oneIdPrefix}login`);
			} else if (isDevelopmentEnvironment(getEnvironment())) {
				handleRedirectAndReloadLogic();
			}
		});

		disneyIdRef.current.on("session-init", () => {
			if (
				!disneyIdRef.current.launchLoginPreventReloadAndRedirect &&
				!disneyIdRef.current.launchReauthPreventReloadAndRedirect
			) {
				handleRedirectAndReloadLogic();
			}
		});

		disneyIdRef.current.on("logout", () => {
			setUser(null);
			if (!disneyIdRef.current.logoutPreventReloadAndRedirect) {
				handleRedirectAndReloadLogic("Logout");
			}
			publishNavigationEvent(`${oneIdPrefix}logout`);
		});

		disneyIdRef.current.on("update", (data) => {
			// data.profile contains the changed info
			data?.profile && setUser({ ...user, ...data.profile });
			publishNavigationEvent(`${oneIdPrefix}update`);
		});

		disneyIdRef.current.on("close", () => {
			setOpenedOneIdModal(false);
			publishNavigationEvent(`${oneIdPrefix}close`);
		});

		["create", "reauth", "refresh", "low-trust"].forEach((event) => {
			disneyIdRef.current.on(event, () =>
				publishNavigationEvent(`${oneIdPrefix}${event}`)
			);
		});
	};

	const handleLogin = (
		event,
		onLoginRedirectTo = null,
		onLogoutRedirectTo = null,
		isEventSource = false,
		preventReloadAndRedirect = false,
		preventExecuteOneIdMethod = false
	) => {
		if (isOneIdSource) {
			handleClick(
				"launchLogin",
				onLoginRedirectTo,
				onLogoutRedirectTo,
				preventReloadAndRedirect,
				preventExecuteOneIdMethod
			)(event);
		} else if (isEventSource) {
			window.location.assign(getLoginUrl(chromeData?.signIn?.href || "/login"));
		}
	};

	const handleLogout = (
		event,
		onLogoutRedirectTo = null,
		isEventSource = false,
		preventReloadAndRedirect = false,
		preventExecuteOneIdMethod = false
	) => {
		setSyndicatedDismissButton(false);
		setStorageMakeCartRequest(true);
		removeCartCookie();
		if (isOneIdSource) {
			disneyIdRef.current.onLogoutRedirectUrl = chromeData?.signOut?.href;
			handleClick(
				"logout",
				null,
				onLogoutRedirectTo,
				preventReloadAndRedirect,
				preventExecuteOneIdMethod
			)(event);
		} else if (isEventSource && onLogoutRedirectTo) {
			window.location.assign(onLogoutRedirectTo);
		} else if (
			disneyIdRef.current?.onLogoutRedirectTo &&
			event?.currentTarget?.href
		) {
			event.currentTarget.href = disneyIdRef.current.onLogoutRedirectTo;
		}
	};

	const handleProfile = (
		event,
		onLoginRedirectTo = null,
		onLogoutRedirectTo = null,
		isEventSource = false
	) => {
		if (chromeData?.signedIn) {
			if (isOneIdSource && chromeData.signedIn?.target === targetOneId) {
				handleClick(
					"launchProfile",
					onLoginRedirectTo,
					onLogoutRedirectTo
				)(event);
			} else if (chromeData.signedIn?.href && isEventSource) {
				window.location.assign(chromeData.signedIn.href);
			}
		}
	};

	const handleClick = (
		method,
		onLoginRedirectTo = null,
		onLogoutRedirectTo = null,
		preventReloadAndRedirect = false,
		preventExecuteOneIdMethod = false
	) => {
		return async (e) => {
			if (
				isLoading ||
				!isOneIdSource ||
				!disneyIdRef.current ||
				!disneyIdRef.current[method]
			)
				return;
			e.preventDefault();
			if (onLoginRedirectTo) {
				disneyIdRef.current.onLoginRedirectTo = onLoginRedirectTo;
			}
			if (onLogoutRedirectTo) {
				disneyIdRef.current.onLogoutRedirectTo = onLogoutRedirectTo;
			}
			if (preventReloadAndRedirect) {
				disneyIdRef.current[
					`${method}PreventReloadAndRedirect`
				] = preventReloadAndRedirect;
			}
			if (!preventExecuteOneIdMethod) {
				try {
					await disneyIdRef.current[method]();
					if (method?.indexOf("launch") === 0) {
						setOpenedOneIdModal(true);
					}
				} catch (error) {
					console.error(error);
				}
			}
		};
	};

	return {
		isLoading,
		user,
		isOneIdSource,
		setUser,
		userType,
		travelAgent,
		handleClick,
		openedOneIdModal,
		affiliations,
		handleLogin,
		handleLogout,
		handleProfile,
	};
};

export default useProfile;
