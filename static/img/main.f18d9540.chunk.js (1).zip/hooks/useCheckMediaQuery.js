import { useEffect, useState } from "react";

const useCheckMediaQuery = (mediaQuery) => {

	const mediaQueryList = window.matchMedia(mediaQuery);
	const [match, setMatch] = useState(mediaQueryList.matches);

	useEffect(() => {
		const handler = (e) => {
			setMatch(e.matches);
		};

		mediaQueryList.addListener(handler);
		return () => mediaQueryList.removeListener(handler);
	//eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return match;
};

export default useCheckMediaQuery;
