import { useEffect, useState } from "react";

const dataStatus = "data-status";

const useScript = (src, position) => {
	const [status, setStatus] = useState(src ? "loading" : "idle");

	useEffect(() => {
		if (!src) {
			setStatus("idle");
			return;
		}

		let script = document.querySelector(`script[src="${src}"]`);

		if (!script) {
			script = document.createElement("script");
			script.src = src;
			script.async = true;
			script.setAttribute(dataStatus, "loading");

			if (position) {
				document[position].appendChild(script);
			}

			const setAttributeFromEvent = (event) => {
				script.setAttribute(
					dataStatus,
					event.type === "load" ? "ready" : "error"
				);
			};

			script.addEventListener("load", setAttributeFromEvent);
			script.addEventListener("error", setAttributeFromEvent);
		} else {
			setStatus(script.getAttribute(dataStatus));
		}

		const setStateFromEvent = (event) => {
			setStatus(event.type === "load" ? "ready" : "error");
		};

		script.addEventListener("load", setStateFromEvent);
		script.addEventListener("error", setStateFromEvent);

		// Remove event listeners on cleanup
		return () => {
			if (script) {
				script.removeEventListener("load", setStateFromEvent);
				script.removeEventListener("error", setStateFromEvent);
			}
		};
	}, [src, position]);

	return status;
};

export default useScript;
