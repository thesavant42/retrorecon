import { getCdn } from "utils";
import Image from "./Image";
const fairyName = "fairy";

const Fairy = () => (
	<div className="syndicated-fairy">
		<Image
			name={fairyName}
			image={{
				url: `${getCdn()}/images/header/fairy.png`,
				title: fairyName,
			}}
		/>
	</div>
);

export default Fairy;
