const AccessibleText = ({ children, role = null, ariaLevel = null }) => {
	return (
		<span
			role={role}
			aria-level={ariaLevel}
			className="syndicated-accessible-text"
		>
			{children}
		</span>
	);
};

export default AccessibleText;
