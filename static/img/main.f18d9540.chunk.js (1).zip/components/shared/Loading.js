import Image from "components/shared/Image";
import { getCdn } from "utils";

const Loading = ({ title = "" }) => (
	<div className="syndicated-loading">
		<Image
			name="loading"
			image={{
				url: `${getCdn()}/gifs/loading/peploading_30x30.gif`,
				title: title,
			}}
		/>
	</div>
);

export default Loading;
