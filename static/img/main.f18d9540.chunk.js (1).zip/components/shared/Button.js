import React, { useContext } from "react";
import Link from "./Link";
import { Context } from "Context";
import { Fragment } from "react";
import AccessibleText from "./AccessibleText";

const mainClass = "syndicated-button";

const Button = ({
	ariaExpanded = null,
	accessibleText = "",
	children,
	className = "",
	customStyles = false,
	disabled = null,
	link = false,
	linkContent = {},
	onClick = null,
	secondary = false,
	tabIndex = null,
	title,
	style = null,
}) => {
	const { config: { brand } = {} } = useContext(Context);

	let classes = className;

	if (!customStyles) {
		classes += ` ${mainClass}`;
		classes += ` ${mainClass}--${brand}`;
		classes += ` ${mainClass}--${secondary ? "secondary" : "primary"}`;
		classes += ` ${mainClass}--${link ? "link" : "button"}`;
	}

	const renderButtonContent = () => {
		let text = title;
		if (link && linkContent) {
			text = linkContent.title;
		}

		return (
			<Fragment>
				{text && (
					<span className={`${mainClass}__gradient`}>
						<span className={`${mainClass}__text`}>{text}</span>
					</span>
				)}
				{children}
				{accessibleText && <AccessibleText>{accessibleText}</AccessibleText>}
			</Fragment>
		);
	};

	return link ? (
		<Link {...linkContent} className={classes} role="button">
			{renderButtonContent()}
		</Link>
	) : (
		<button
			aria-expanded={ariaExpanded}
			className={classes}
			onClick={onClick}
			tabIndex={tabIndex}
			disabled={disabled}
			style={style}
		>
			{renderButtonContent()}
		</button>
	);
};

export default Button;
