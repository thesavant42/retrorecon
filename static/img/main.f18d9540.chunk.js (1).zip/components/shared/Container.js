const Container = ({ direction, children }) => {
	const mainClass = "syndicated-container";
	let classes = mainClass;

	if (direction) classes += ` ${mainClass}--flex-${direction}`;

	return <div className={classes}>{children}</div>;
};

export default Container;
