import { getCdn } from "utils";

const Icon = ({
	icon = null,
	className = "",
	rotate = false,
	title = null,
}) => {
	const iconClass = `syndicated-icon${icon ? ` syndicated-icon--${icon}` : ""}${
		rotate ? " syndicated-icon--rotate" : ""
	} ${className}`;
	const iconUrl = `${getCdn(true)}/icons/pep/${icon}.svg`;

	if (!icon) {
		return null;
	}

	return (
		<img alt={title || ""} title={title} className={iconClass} src={iconUrl} />
	);
};

export default Icon;
