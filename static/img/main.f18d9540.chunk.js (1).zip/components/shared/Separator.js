const Separator = ({ vertical = false, section = "" }) => (
	<div
		className={`syndicated-separator--${vertical ? "vertical" : "horizontal"}${
			section ? ` syndicated-separator--${section}` : ""
		}`}
	></div>
);

export default Separator;
