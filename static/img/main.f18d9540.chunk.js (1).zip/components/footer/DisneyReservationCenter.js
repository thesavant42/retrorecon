import Separator from "components/shared/Separator";

const mainClass = "syndicated-footer__disney-reservation-center";
const DisneyReservationCenter = ({ title, subtitle }) =>
	title || subtitle ? (
		<div className={mainClass}>
			<Separator section="footer" />
			<ul className={`${mainClass}__container`}>
				{title && (
					<li
						className={`${mainClass}__container__title`}
						dangerouslySetInnerHTML={{ __html: title }}
					></li>
				)}
				{subtitle && (
					<li
						className={`${mainClass}__container__subtitle`}
						dangerouslySetInnerHTML={{ __html: subtitle }}
					></li>
				)}
			</ul>
			<Separator section="footer" />
		</div>
	) : null;

export default DisneyReservationCenter;
