import Link from "components/shared/Link";
import { Fragment } from "react";
import Item from "./Item";
import SocialMediaIcon from "./SocialMediaIcon";
import Column from "./Column";

const socialInformationItemClass = "syndicated-footer__social-information-item";

const SocialInformationItem = ({
	id,
	title,
	descriptions: elements = [],
	webLinkList = [],
}) => {
	const renderElement = ({ url: src, title, id }, link, index = 0) => {
		return (
			<Link
				{...link}
				key={index}
				className={`syndicated-footer__link ${socialInformationItemClass}__link`}
			>
				<SocialMediaIcon
					src={src}
					title={title}
					className={id ? `syndicated-social-icon--${id}` : ""}
				/>
			</Link>
		);
	};

	return (
		<Item title={title || "<br>"} emptyTitle={!title} id={id}>
			<div className={socialInformationItemClass}>
				{elements?.length > 0 && (
					<Fragment>
						{elements.length > 1 ? (
							elements?.map((element, index) =>
								renderElement(element.image || {}, element.link, index)
							)
						) : (
							<Fragment>
								{elements[0].image &&
									renderElement(elements[0].image || {}, elements[0].link)}
								{elements[0].text && (
									<div
										className={`${socialInformationItemClass}__content${
											elements[0].image
												? ` ${socialInformationItemClass}__content--with-image`
												: ""
										}`}
									>
										<span>{elements[0].text}</span>
										<Link
											{...elements[0].link}
											className="syndicated-footer__link"
										/>
									</div>
								)}
							</Fragment>
						)}
					</Fragment>
				)}
				{webLinkList?.length > 0 && <Column webLinkList={webLinkList} />}
			</div>
		</Item>
	);
};

export default SocialInformationItem;
