const Title = ({ title }) =>
	title ? (
		<p
			dangerouslySetInnerHTML={{ __html: title }}
			className="syndicated-footer__title"
		/>
	) : null;

export default Title;
