import { Fragment } from "react";
import Column from "components/footer/Column";
import AccessibleText from "components/shared/AccessibleText";
import Separator from "components/shared/Separator";

const Columns = ({ columns = [], accessibleText }) => {
	return (
		<Fragment>
			<AccessibleText>{accessibleText}</AccessibleText>
			<div className="syndicated-footer__list">
				{columns.map((section, index) => (
					<section
						key={index}
						className={`syndicated-footer__list__column syndicated-footer__list__column--${section.id}`}
					>
						{section.modules?.map((content, index) => (
							<Column {...content} key={index} />
						))}
					</section>
				))}
			</div>
			<Separator section="footer" />
		</Fragment>
	);
};

export default Columns;
