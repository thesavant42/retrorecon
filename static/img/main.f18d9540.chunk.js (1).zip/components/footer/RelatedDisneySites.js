import Title from "components/footer/Title";
import Column from "./Column";

const RelatedDisneySites = ({ title, linksColumns = [] }) => (
	<ul className="syndicated-footer__language-and-related-sites-container">
		<li>
			<Title title={title} />
		</li>
		{linksColumns?.map((section, index) => (
			<li key={index} className="syndicated-footer__list__column">
				<Column webLinkList={section.webLinkList} />
			</li>
		))}
	</ul>
);

export default RelatedDisneySites;
