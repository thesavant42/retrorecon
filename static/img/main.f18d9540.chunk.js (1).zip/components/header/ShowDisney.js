import { useContext } from "react";
import Link from "components/shared/Link";
import Icon from "components/shared/Icon";
import { Context } from "Context";
import { brands } from "config.json";
import { Fragment } from "react";

const ShowDisney = ({ action, open, isMobileView = false }) => {
	const {
		config: { showDisney, brand },
		headerData: { chrome },
	} = useContext(Context);

	const showModal = brands[brand]?.showVisitDisneyModal || false;

	const renderContent = (title) => {
		return (
			<Fragment>
				{title}
				<Icon
					icon="icon_expand-show-more"
					className={open ? "syndicated-icon--rotate-180" : ""}
				/>
			</Fragment>
		);
	};

	if (isMobileView) {
		return chrome?.visitDisney ? (
			<div className="syndicated-show-disney">
				<Link
					{...chrome?.visitDisney}
					className="syndicated-show-disney__link"
				></Link>
			</div>
		) : null;
	}

	if (!showDisney) return null;

	if (typeof open === "undefined") {
		return null;
	}

	return (
		<div
			className="syndicated-navigation__chrome__disney"
			onClick={showModal ? null : action}
		>
			{showModal
				? chrome?.visitDisney && (
						<Link
							{...chrome.visitDisney}
							className="syndicated-navigation__chrome__disney"
							title={chrome?.showDisney}
						/>
				  )
				: open
				? renderContent(chrome?.hideDisney)
				: renderContent(chrome?.showDisney)}
		</div>
	);
};

export default ShowDisney;
