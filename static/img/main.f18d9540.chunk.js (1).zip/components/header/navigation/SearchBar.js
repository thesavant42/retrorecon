import React, { useState, useEffect, useRef, useContext } from "react";
import useFetch from "hooks/useFetch";
import Icon from "components/shared/Icon";
import Link from "components/shared/Link";
import { Context } from "Context";
import Button from "components/shared/Button";
import { getCdn, mapString } from "utils";
import { searchService } from "config.json";

const { origin, pathname } = window.location;
const iconsCdn = getCdn(true);

const SearchBar = () => {
	const {
		headerData: { chrome },
		config: { basePath, searchBar },
		profileData: { userType },
	} = useContext(Context);
	const [searchQuery, setSearchQuery] = useState("");
	const [searchParams, setSearchParams] = useState(null);
	const [fetchTrigger, setFetchTrigger] = useState(0);
	const [showSuggestions, setShowSuggestions] = useState(false);
	const { response } = useFetch(
		searchParams ? `${basePath}${searchService.apiUrl}` : "",
		searchParams,
		0,
		fetchTrigger
	);
	const ref = useRef(null);

	const handleSubmit = (event) => {
		if (event.key === "Enter" && searchQuery) {
			window.location.assign(
				`${origin}${basePath}/search/?searchQuery=${searchQuery
					.trim()
					.replace(/ +/g, "+")}`
			);
		}
	};

	const fullWordsEllipsis = (text = "") => {
		if (text.length > 40) {
			const fitText = text.substring(0, 36);
			text = fitText.substring(0, fitText.lastIndexOf(" ")) + "...";
		}
		return text;
	};

	const extractIcon = (iconSource) => {
		return iconSource.split('<span class="icon__')[1].split(" ")[0];
	};

	const handleInnerClick = () => {
		if (searchQuery && response?.links?.length > 0) {
			setShowSuggestions(true);
		}
	};

	useEffect(() => {
		const loadResultsTimeout = setTimeout(() => {
			const validSearchQuery = searchQuery.trim().replace(/  +/g, " ");
			if (validSearchQuery.replace(/  +/g, "").length > 1) {
				const pageName =
					pathname
						.split("/")
						.filter((part) => part.length)
						.join("_") || "homepage";
				setSearchParams({
					method: "POST",
					body: mapString(
						searchService.baseParams,
						userType || "GUEST",
						pageName,
						validSearchQuery
					),
					headers: {
						"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
					},
				});
				setFetchTrigger((fetch) => fetch + 1);
			} else if (validSearchQuery.length === 0) {
				setShowSuggestions(false);
			}
		}, 600);
		return () => {
			clearTimeout(loadResultsTimeout);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [searchQuery]);

	useEffect(() => {
		if (response && response.links?.length > 0 && searchQuery) {
			setShowSuggestions(true);
		} else if (!response || response.links?.length === 0) {
			setShowSuggestions(false);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [response]);

	useEffect(() => {
		const handleClickOutside = (event) => {
			if (!ref.current?.contains(event.target)) {
				setShowSuggestions(false);
			}
		};
		document.addEventListener("click", handleClickOutside, true);
		return () => window.removeEventListener("click", handleClickOutside, true);
	}, []);

	return searchBar ? (
		<div ref={ref} className="syndicated-navigation__chrome__search">
			<div
				className={
					"syndicated-navigation__chrome__search__form" +
					(showSuggestions
						? " syndicated-navigation__chrome__search__form--focus"
						: "")
				}
			>
				<Button
					accessibleText={chrome?.confirmSearch}
					className="syndicated-icon syndicated-icon--search"
					customStyles
					onClick={() => handleSubmit({ key: "Enter" })}
					style={{
						backgroundImage: `url(${iconsCdn}/icons/pep/search.svg)`,
					}}
				/>
				<input
					aria-label={chrome?.searchDisney}
					onClick={handleInnerClick}
					className="syndicated-navigation__chrome__search__form__input"
					type="text"
					value={searchQuery}
					onKeyPress={handleSubmit}
					onChange={(event) => setSearchQuery(event.target.value)}
					placeholder={chrome?.searchDisney}
					maxLength="254"
					autoComplete="off"
					name="searchQuery"
				/>
				<Button
					accessibleText={chrome?.clearSearch}
					className="syndicated-icon syndicated-icon--close-button"
					customStyles
					disabled={!searchQuery}
					onClick={() => setSearchQuery("")}
					style={{
						backgroundImage: `url(${iconsCdn}/icons/pep/close-button.svg)`,
					}}
				/>
			</div>
			{showSuggestions && searchQuery && (
				<ul className="syndicated-navigation__chrome__search__autosuggest">
					<li className="syndicated-navigation__chrome__search__autosuggest__list-item">
						{chrome?.searchResults}
					</li>
					{response?.links?.map((link) => (
						<li
							key={link.id}
							className="syndicated-navigation__chrome__search__autosuggest__list-item"
							role="presentation"
						>
							<Link href={link.url}>
								<span className="syndicated-icon-container">
									<Icon icon={extractIcon(link.webFontCode)} />
								</span>
								<div className="syndicated-link__details">
									<div dangerouslySetInnerHTML={{ __html: link.label }} />
									<div className="syndicated-link__details__description">
										{fullWordsEllipsis(link.desc)}
									</div>
								</div>
							</Link>
						</li>
					))}
				</ul>
			)}
		</div>
	) : null;
};

export default SearchBar;
