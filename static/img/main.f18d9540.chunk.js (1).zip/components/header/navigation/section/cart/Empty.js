import { Fragment } from "react";
import Separator from "components/shared/Separator";
import Footer from "./Footer";
import LinkGroup from "../LinkGroup";

const Empty = ({
	brand,
	text,
	id,
	price,
	descriptions = [],
	separateFooter = false,
}) => (
	<Fragment>
		<Separator />
		<LinkGroup id={id} text={text} descriptions={descriptions} />
		{separateFooter && <Separator />}
		<Footer showButtons={false} price={price} brand={brand} />
	</Fragment>
);

export default Empty;
