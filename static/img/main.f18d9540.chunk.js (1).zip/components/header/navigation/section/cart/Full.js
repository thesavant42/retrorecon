import { Fragment } from "react";
import Footer from "./Footer";
import Composite from "./CompositeItem";
import Message from "./Message";
import Separator from "components/shared/Separator";
import { arrayIsEmpty, objectIsEmpty } from "utils";

const Full = ({
	brand,
	message,
	compositeItems,
	standaloneItems,
	standaloneItemsTitle,
	currencyChangeDetail,
	price,
	buttons,
	startOver,
	emptyCart,
}) => (
	<Fragment>
		{!objectIsEmpty(message) && <Message {...message} />}
		{!arrayIsEmpty(compositeItems) &&
			compositeItems.map((item, key) => (
				<Fragment key={key}>
					<Separator />
					<Composite
						title={item.title}
						category={item.category}
						items={item.items}
						separateTitle={false}
						separateItems={item?.separateItems}
					/>
					<Separator />
				</Fragment>
			))}
		{!arrayIsEmpty(standaloneItems) && (
			<Composite
				title={standaloneItemsTitle}
				category="standalone"
				items={standaloneItems}
				separateItems={true}
			/>
		)}
		{(!arrayIsEmpty(compositeItems) || !arrayIsEmpty(standaloneItems)) && (
			<Footer
				brand={brand}
				price={price}
				showLink={objectIsEmpty(message)}
				buttons={buttons}
				currencyChangeDetail={currencyChangeDetail}
				startOver={startOver}
				emptyCart={emptyCart}
			/>
		)}
	</Fragment>
);

export default Full;
