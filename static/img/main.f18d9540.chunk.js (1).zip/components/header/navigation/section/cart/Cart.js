import React, { useContext, useState, useEffect, useRef } from "react";
import SectionTitle from "components/header/navigation/section/Title";
import Flyout from "components/header/navigation/Flyout";
import Loading from "components/shared/Loading";
import Full from "./Full";
import Empty from "./Empty";
import useFetch from "hooks/useFetch";
import useKeyboardNav from "hooks/useKeyboardNav";
import useSessionStorage from "hooks/useSessionStorage";
import { arrayIsEmpty, objectIsEmpty, mapString } from "utils";
import { getCookie, setCookie, removeCookie } from "utils/cookie";
import { Context } from "Context";
import config from "config.json";
const syndicatedMakeCartRequest = "syndicatedMakeUserCartRequest";
const cartUserIdentifier = "cartUserIdentifier";
const cartIdName = "cartId";
const cartEvent = "navigationCart";

const Cart = ({
	cartEmpty,
	cartLabel,
	checkOut,
	descriptions = [],
	icon,
	id,
	link,
	price: initialPrice,
	standaloneItemsTitle: otherItems,
	title,
	viewCartCheckOut,
	viewDetails,
	startOver,
	emptyCart,
	accessibiltyText,
	isMenuActive,
	setIsMenuActive,
}) => {
	const {
		config: { brand, store },
		profileData: { user },
	} = useContext(Context);

	const [storageMakeCartRequest, setStorageMakeCartRequest] = useSessionStorage(
		syndicatedMakeCartRequest
	);

	const isDCL = brand === "dcl";
	const showFlyout =
		isDCL || !window.location.pathname.split("/").includes("cart");
	const [countUrl, setCountUrl] = useState("");
	const [detailsUrl, setDetailsUrl] = useState("");
	const [scope] = useState(isDCL ? "" : `${brand}${store ? `_${store}` : ""}`);
	const [hasItems, setHasItems] = useState(false);
	const [items, setItems] = useState([]);
	const [standaloneItems, setStandaloneItems] = useState([]);
	const [compositeItems, setCompositeItems] = useState([]);
	const [standaloneItemsTitle, setStandaloneItemsTitle] = useState("");
	const [price, setPrice] = useState(initialPrice);
	const [unavailableItemsMessage, setUnavailableItemsMessage] = useState({});
	const [currencyChangeDetail, setCurrencyChangeDetail] = useState(null);
	const [cartCookieJarName, setCartCookieJarName] = useState("");
	const [cartCookieJarValue, setCartCookieJarValue] = useState({});
	const sectionRef = useRef(null);
	const {
		onFocus,
		handleKeyDown,
		handleOnFocus,
		handleOnBlur,
	} = useKeyboardNav(sectionRef, isMenuActive, setIsMenuActive);

	const mainClass = "syndicated-section";
	let classes = mainClass;
	if (id) classes += ` ${mainClass}--${id}`;
	classes += ` ${mainClass}--${hasItems ? "full" : "empty"}`;
	if (!showFlyout) classes += ` ${mainClass}--no-flyout`;
	if (isMenuActive && onFocus) classes += ` ${mainClass}--onfocus`;

	const countResponse = useFetch(
		countUrl,
		{ headers: { swid: user?.swid || "" } },
		0,
		countUrl
	);
	const detailsResponse = useFetch(
		detailsUrl,
		{ headers: { swid: user?.swid || "" } },
		0,
		detailsUrl
	);

	const getCartCookies = () => {
		const cartCookieName = isDCL
			? "new"
			: user?.swid
			? cartUserIdentifier
			: cartIdName;
		const cartCookieJarName = isDCL ? "cartIdMapping" : `CART-${scope}_jar`;
		setCartCookieJarName(cartCookieJarName);
		let cartCookieJarContent = getCookie(cartCookieJarName);
		if (cartCookieJarContent) {
			try {
				cartCookieJarContent = JSON.parse(
					decodeURIComponent(cartCookieJarContent)
				);
				if (
					cartCookieJarContent[cartCookieName] ||
					(user?.swid && cartCookieJarContent[cartIdName])
				) {
					setCartCookieJarValue(cartCookieJarContent);
				}
			} catch (e) {
				console.info("Error parsing the cart cookie, content is malformed");
			}
		}
	};

	const setRequestUrls = () => {
		const isLoggedIn = !!user?.swid;

		const {
			cartId = "",
			new: cartIdDcl = null,
			[cartUserIdentifier]: {
				id = null,
				type = !isDCL && isLoggedIn ? "GUEST" : "",
				idType = !isDCL && isLoggedIn ? "swid" : "",
			} = {},
		} = cartCookieJarValue;

		// if swid cookie matches the cartUserIdentifier swid cookie of the CART-XX_jar
		const isUserCartCookieSet =
			isLoggedIn && id && type && idType && id === user.swid;
		isUserCartCookieSet && setStorageMakeCartRequest(true);
		const makeRequest =
			isLoggedIn && !isUserCartCookieSet && storageMakeCartRequest;
		const isValidCartDCL = !!(isDCL && cartIdDcl);
		const isValidCartOtherBrands = !!(
			scope &&
			(cartId || isUserCartCookieSet || makeRequest)
		);

		!isDCL &&
			isValidCartOtherBrands &&
			!hasItems &&
			setCountUrl(
				mapString(config.cart.apiUrl, "count", scope, cartId, type, idType)
			);

		if (isValidCartDCL || (isValidCartOtherBrands && hasItems)) {
			setDetailsUrl(
				mapString(
					config.cart.apiUrl,
					"details",
					scope,
					isDCL ? cartIdDcl : cartId,
					type,
					idType
				)
			);
		}
	};

	const setUserCartCookie = () => {
		const cookieExpirationInDays = 30;
		if (
			!isDCL &&
			user?.swid &&
			(objectIsEmpty(cartCookieJarValue) || cartCookieJarValue?.[cartIdName])
		) {
			const cookieContent = {
				[cartUserIdentifier]: {
					type: "GUEST",
					id: user?.swid,
					idType: "swid",
				},
			};
			setCookie(
				cartCookieJarName,
				encodeURIComponent(JSON.stringify(cookieContent)),
				cookieExpirationInDays
			);
			setCartCookieJarValue(cookieContent);
		}
	};

	const resetCartCookie = () => {
		user?.swid && setStorageMakeCartRequest(false);
		removeCookie(cartCookieJarName);
		setCartCookieJarValue({});
	};

	const resetCart = () => {
		setCountUrl("");
		setDetailsUrl("");
		setItems([]);
		setHasItems(false);
	};

	const cartEventLogic = (event) => {
		if (event?.detail?.method === "reload") {
			resetCart();
		}
	};

	useEffect(() => {
		typeof storageMakeCartRequest === "undefined" &&
			setStorageMakeCartRequest(true);
		//eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useEffect(() => {
		getCartCookies();
		if (!user?.swid && hasItems) {
			resetCart();
		}
		//eslint-disable-next-line react-hooks/exhaustive-deps
	}, [user?.swid, store]);

	useEffect(() => {
		(cartCookieJarValue || user?.swid) && setRequestUrls();
		//eslint-disable-next-line react-hooks/exhaustive-deps
	}, [cartCookieJarValue, storageMakeCartRequest, user?.swid, hasItems]);

	useEffect(() => {
		if (countResponse.response) {
			if (countResponse.response.totalNumberOfItems > 0) {
				setHasItems(true);
				setUserCartCookie();
			} else {
				resetCartCookie();
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [countResponse?.response]);

	useEffect(() => {
		if (countResponse?.error) {
			if (countResponse.error?.status === 404) {
				resetCartCookie();
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [countResponse?.error]);

	useEffect(() => {
		if (!arrayIsEmpty(detailsResponse?.response?.items)) {
			setHasItems(true);
			setItems(detailsResponse.response.items);
			!objectIsEmpty(detailsResponse.response?.price) &&
				setPrice(detailsResponse.response.price);
			!objectIsEmpty(detailsResponse.response?.message) &&
				setUnavailableItemsMessage(detailsResponse.response.message);
			!objectIsEmpty(detailsResponse.response?.currencyChangeDetail) &&
				setCurrencyChangeDetail(detailsResponse.response.currencyChangeDetail);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [detailsResponse?.response]);

	useEffect(() => {
		detailsResponse?.error && setHasItems(false);
	}, [detailsResponse?.error]);

	useEffect(() => {
		setCompositeItems(items.filter((item) => !arrayIsEmpty(item?.items)));
		setStandaloneItems(items.filter((item) => !item.items));
	}, [items]);

	useEffect(() => {
		!arrayIsEmpty(standaloneItems) &&
			!arrayIsEmpty(compositeItems) &&
			setStandaloneItemsTitle(otherItems);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [standaloneItems, compositeItems]);

	useEffect(() => {
		document.addEventListener(cartEvent, cartEventLogic);
		return () => {
			document.removeEventListener(cartEvent, cartEventLogic);
		};
	});

	return (
		<div
			className={classes}
			tabIndex={-1}
			ref={sectionRef}
			onKeyDown={handleKeyDown}
			onFocus={handleOnFocus}
			onBlur={handleOnBlur}
		>
			<SectionTitle
				link={link}
				name={id}
				icon={hasItems ? "cart-full" : icon}
				title={title}
				accessibiltyText={accessibiltyText}
			/>
			{showFlyout && (
				<Flyout right={true} name={id}>
					<Flyout.Primary name={id}>
						<div className={`${mainClass}__content`}>
							<h2 className={`${mainClass}__content__title`}>{cartLabel}</h2>
							{countResponse?.loading || detailsResponse?.loading ? (
								<Loading />
							) : hasItems ? (
								<Full
									brand={brand}
									message={unavailableItemsMessage}
									compositeItems={compositeItems}
									standaloneItems={standaloneItems}
									standaloneItemsTitle={standaloneItemsTitle}
									price={price}
									currencyChangeDetail={currencyChangeDetail}
									startOver={startOver}
									emptyCart={emptyCart}
									buttons={{
										checkOut,
										viewCartCheckOut,
										viewDetails,
									}}
								/>
							) : (
								<Empty
									id={id}
									brand={brand}
									text={cartEmpty}
									descriptions={descriptions || []}
									price={price?.sections || {}}
									separateFooter={isDCL}
								/>
							)}
						</div>
					</Flyout.Primary>
				</Flyout>
			)}
		</div>
	);
};

export default Cart;
