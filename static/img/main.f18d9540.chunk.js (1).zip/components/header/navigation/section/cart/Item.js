import React from "react";
import Title from "components/shared/Title";
import Flight from "./FlightItem";
import Room from "./RoomItem";

const Item = (props) => {
	const { category = "", type = "", title = "", content = "" } = props;

	const mainClass = "syndicated-section__content__item";
	let classes = mainClass;
	const name = type || category;

	if (name) classes += ` ${mainClass}--${name}`;

	if (category === "room") return <Room {...content} />;

	if (category === "flight") return <Flight {...props} />;

	return (
		<div className={classes}>
			<Title name={name} title={title} subTitle={content} />
		</div>
	);
};

export default Item;
