import React, { Fragment } from "react";
import Item from "./Item";
import Separator from "components/shared/Separator";
import { arrayIsEmpty } from "utils";

const Composite = ({
	category,
	title,
	items,
	separateItems = false,
	separateTitle = true,
}) => {
	const mainClass = "syndicated-section__content__composite";
	let classes = mainClass;
	if (category) classes += ` ${mainClass}--${category}`;

	if (arrayIsEmpty(items)) return null;

	return (
		<div className={classes}>
			{title ? (
				<div className={`${mainClass}__title`}>{title}</div>
			) : (
				separateTitle && <Separator />
			)}
			{items.map((item, key) => (
				<Fragment key={key}>
					<Item {...item} />
					{separateItems && <Separator />}
				</Fragment>
			))}
		</div>
	);
};

export default Composite;
