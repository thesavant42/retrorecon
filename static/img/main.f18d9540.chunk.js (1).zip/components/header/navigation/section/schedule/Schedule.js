import Icon from "components/shared/Icon";
import Link from "components/shared/Link";
import { Context } from "Context";
import { Fragment, useContext } from "react";
import { mapString } from "utils";

const currentDate = new Date().toISOString().split("T")[0];
const scheduleClass = "syndicated-schedule";
const scheduleContainerClass = `${scheduleClass}__container`;

const Schedule = ({
	description,
	link,
	linkClass = "",
	listItemClass = "",
}) => {
	const {
		headerData: { chrome },
	} = useContext(Context);

	if (!description?.parkHour?.schedule?.schedules) {
		return null;
	}

	const renderClosedSchedules = (type, opened) => {
		return opened === false ? chrome?.[`${type.toLowerCase()}Park`] : "";
	};

	const renderSchedules = () => {
		const schedules = description?.parkHour?.schedule?.schedules;
		return (schedules || []).map((schedule, index) => {
			return (
				<div
					key={index}
					itemProp="openingHoursSpecification"
					itemScope=""
					itemType="http://schema.org/OpeningHoursSpecification"
					className={`${scheduleContainerClass}__hours__specification ${scheduleContainerClass}__hours__specification--${
						schedule.opened ? "opened" : "closed"
					}`}
				>
					<div itemProp="validFrom" content={currentDate}></div>
					<div itemProp="validThrough" content={currentDate}></div>
					{schedule.opened &&
					schedule.startLocaleTime &&
					schedule.endLocaleTime ? (
						<Fragment>
							<span itemProp="opens" content={schedule.startLocaleTime}>
								{schedule.startLocaleTime}
							</span>
							{mapString(chrome?.operatingPark, "", "", "")}
							<span itemProp="closes" content={schedule.endLocaleTime}>
								{schedule.endLocaleTime}
							</span>
						</Fragment>
					) : (
						renderClosedSchedules(schedule.type, schedule.opened)
					)}
				</div>
			);
		});
	};

	const renderSchedule = () => (
		<Fragment>
			<Icon icon={description?.icon} />
			<div className={`${scheduleContainerClass}__hours`}>
				<div
					itemProp="name"
					className={`${scheduleContainerClass}__hours__title`}
				>
					{link?.title || description?.title}
				</div>
				{renderSchedules()}
			</div>
		</Fragment>
	);

	return (
		<li
			className={`${scheduleClass} ${listItemClass}`}
			itemScope=""
			itemType="http://schema.org/TouristAttraction"
		>
			{link ? (
				<Link {...link} className={`${scheduleContainerClass} ${linkClass}`}>
					{renderSchedule()}
				</Link>
			) : (
				renderSchedule()
			)}
		</li>
	);
};

export default Schedule;
