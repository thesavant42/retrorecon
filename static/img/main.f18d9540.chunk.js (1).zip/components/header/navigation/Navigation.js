import React, { useState, useContext, useEffect, useRef } from "react";
import { Context } from "Context";
import Link from "components/shared/Link";
import Container from "components/shared/Container";
import SectionCart from "./section/cart/Cart";
import LanguageSelector from "./LanguageSelector";
import Section from "./section/Section";
import SearchBar from "./SearchBar";
import useCheckMediaQuery from "hooks/useCheckMediaQuery";
import { mobileMediaQuery, brands, focusableElements } from "config.json";
import { getCdn } from "utils";
import Profile from "../profile/Profile";
import { Fragment } from "react";
import AccessibleText from "components/shared/AccessibleText";
import Button from "components/shared/Button";
import Matterhorn from "../Matterhorn";
import ShowDisney from "../ShowDisney";

const syndicatedNavigationClass = "syndicated-navigation";
const syndicatedNavigationNavClass = `${syndicatedNavigationClass}__nav`;
const syndicatedNavigationChromeClass = `${syndicatedNavigationClass}__chrome`;
const syndicatedCdn = getCdn();
const iconsCdn = getCdn(true);

const scrollTopAndLeft = (top = 0, left = 0) => {
	window.scrollTo({
		top,
		left,
		behavior: "smooth",
	});
};

const Navigation = ({ headerRef, showLogo }) => {
	const {
		config: {
			basePath,
			brand,
			chrome: showChrome,
			chromeLinks,
			languageSelector,
			logo,
			navigation: showNavigation,
			position,
			searchBar,
			showDisney,
			showSections,
			store,
		},
		headerData: { navigation, chrome },
		profileData: { openedOneIdModal, userType },
		modal,
	} = useContext(Context);

	const navRef = useRef(null);
	const sectionNavRef = useRef(null);
	const [isMenuActive, setIsMenuActive] = useState(false);
	const [menuToggle, setMenuToggle] = useState(false);
	const [searchBarToggle, setSearchBarToggle] = useState(false);
	const isMobileView = useCheckMediaQuery(mobileMediaQuery);
	const [collapsedSection, setCollapsedSection] = useState("");
	const [openMatterhorn, setOpenMatterhorn] = useState(false);
	const brandLogoSrc = `${syndicatedCdn}/logos/${
		brands[brand].logo || `${brand}.svg`
	}`;
	const brandLogo = (
		<img src={brandLogoSrc} alt={`${brands[brand]?.name} Logo`} />
	);
	const brandLogoClasses = `${syndicatedNavigationNavClass}__logo ${syndicatedNavigationNavClass}__logo--${brand}${
		logo ? "" : ` ${syndicatedNavigationNavClass}__logo--hide`
	}`;
	const showSearchBar =
		!store &&
		searchBar &&
		!brands[brand]?.hideSearchBarForUserTypes?.includes(userType);

	useEffect(() => {
		if (isMobileView) {
			document.addEventListener("click", handleOutsideClick, true);
			document.addEventListener("focus", handleOutsideClick, true);
		}
		return () => {
			document.removeEventListener("click", handleOutsideClick, true);
			document.removeEventListener("focus", handleOutsideClick, true);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const handleOutsideClick = (e) => {
		!sectionNavRef.current?.contains(e.target) &&
			!e.target.classList.contains(
				"syndicated-navigation__nav__toggle--menu"
			) &&
			handleCloseMenu();
	};

	const handleCloseMenu = () => {
		document.body.classList.remove("navigation-nav-open");
		setMenuToggle(false);
	};

	const handleMenuToggle = () => {
		document.body.classList.toggle("navigation-nav-open");
		scrollTopAndLeft();
		setMenuToggle((prevState) => !prevState);
	};

	const handleSearchBarToggle = () => {
		setSearchBarToggle((prevState) => !prevState);
	};

	const handleSkipNavigation = () => {
		const header = headerRef;
		const headerHeight = header?.current?.scrollHeight || 0;
		const matterhorn = document.getElementById("goc-bar");
		const matterhornHeight = matterhorn?.scrollHeight || 0;
		const totalHeight = headerHeight + matterhornHeight;
		scrollTopAndLeft(position === "sticky" ? matterhornHeight : totalHeight);
	};

	const renderSections = () => {
		return (
			showSections &&
			navigation?.map((section, key) => {
				return section.id === "cart" ? (
					<SectionCart
						key={key}
						{...section}
						isMenuActive={isMenuActive}
						setIsMenuActive={setIsMenuActive}
					/>
				) : (
					<Section
						{...section}
						setCollapsedSection={setCollapsedSection}
						collapse={
							!isMobileView || (isMobileView && collapsedSection === section.id)
						}
						key={key}
						isMenuActive={isMenuActive}
						setIsMenuActive={setIsMenuActive}
						store={store}
						brand={brand}
					/>
				);
			})
		);
	};

	const renderBrandLogo = () => {
		return store ? (
			<div className={brandLogoClasses}>{brandLogo}</div>
		) : (
			<Link
				href={`${window.location.origin}${basePath}`}
				className={brandLogoClasses}
			>
				{brandLogo}
			</Link>
		);
	};

	const handleShowDisney = () => {
		setOpenMatterhorn((prevState) => !prevState);
	};

	useEffect(() => {
		if (!isMobileView) {
			setSearchBarToggle(false);
		}
	}, [isMobileView]);

	useEffect(() => {
		if ((modal || openedOneIdModal) && menuToggle) {
			handleMenuToggle();
		}
	}, [modal, openedOneIdModal, menuToggle]);

	useEffect(() => {
		if (isMobileView && menuToggle) {
			const focusable = sectionNavRef?.current?.querySelector(
				focusableElements
			);
			focusable.focus();
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [menuToggle]);

	return (
		<div
			className={
				syndicatedNavigationClass +
				(store ? ` ${syndicatedNavigationClass}--store` : "")
			}
			ref={navRef}
		>
			<div id="goc" />
			{showChrome && showDisney && !brands[brand].showVisitDisneyModal && (
				<Matterhorn open={openMatterhorn} />
			)}
			<Container>
				{showChrome && (
					<div className={syndicatedNavigationChromeClass}>
						<ShowDisney open={openMatterhorn} action={handleShowDisney} />
						<Button
							className={`${syndicatedNavigationChromeClass}__skip-navigation`}
							customStyles
							onClick={handleSkipNavigation}
							tabIndex={1}
						>
							{chrome?.skipNavigation}
						</Button>
						<div
							className={`${syndicatedNavigationChromeClass}__links ${syndicatedNavigationChromeClass}__links--${brand}`}
						>
							{!isMobileView && (
								<Profile username reservation userStatusLinks />
							)}
							{languageSelector && <LanguageSelector />}
							{chromeLinks &&
								chrome?.elements?.map((element, key) =>
									element.link ? (
										<div key={key}>
											<Link {...element.link} />
										</div>
									) : null
								)}
						</div>
						{!isMobileView && showSearchBar && <SearchBar />}
					</div>
				)}
				{(showNavigation || showLogo) && (
					<div
						className={`${syndicatedNavigationNavClass} ${syndicatedNavigationNavClass}--${brand}`}
					>
						{showNavigation && (
							<Button
								ariaExpanded={menuToggle}
								accessibleText={chrome?.accessibiltyTextShowNavigation}
								className={`${syndicatedNavigationNavClass}__toggle ${syndicatedNavigationNavClass}__toggle--menu`}
								customStyles
								onClick={handleMenuToggle}
								style={{
									backgroundImage: `url(${iconsCdn}/icons/pep/menu-global-nav.svg)`,
								}}
							/>
						)}
						{renderBrandLogo()}
						<div id="logoSchema" itemType="http://schema.org/Organization">
							<link itemProp="url" href={window.location.origin} />
							<link itemProp="logo" href={brandLogoSrc} />
						</div>
						{showNavigation && (
							<Fragment>
								<nav
									role="menubar"
									ref={sectionNavRef}
									className={`${syndicatedNavigationNavClass}__sections ${
										menuToggle
											? `${syndicatedNavigationNavClass}__sections--open`
											: ""
									}`}
								>
									<AccessibleText role="heading" ariaLevel="1">
										{chrome?.accessibiltyTextNavigationLinks}
									</AccessibleText>
									{isMobileView && <Profile username />}
									{renderSections()}
									{isMobileView && !store && (
										<Fragment>
											{languageSelector && <LanguageSelector />}
											<Profile reservation userStatusLinks showIcon />
											<ShowDisney isMobileView></ShowDisney>
										</Fragment>
									)}
								</nav>
								<Button
									ariaExpanded={searchBarToggle}
									accessibleText={chrome?.accessibiltyTextShowSearch}
									className={`${syndicatedNavigationNavClass}__toggle ${syndicatedNavigationNavClass}__toggle--search ${
										showSearchBar
											? ""
											: `${syndicatedNavigationNavClass}__toggle--search--hidden`
									}`}
									customStyles
									onClick={handleSearchBarToggle}
									style={{
										backgroundImage: `url(${iconsCdn}/icons/pep/search.svg)`,
									}}
									disabled={!showSearchBar}
								/>
							</Fragment>
						)}
					</div>
				)}
				{isMobileView && searchBarToggle && showNavigation && showSearchBar && (
					<SearchBar />
				)}
			</Container>
		</div>
	);
};

export default Navigation;
