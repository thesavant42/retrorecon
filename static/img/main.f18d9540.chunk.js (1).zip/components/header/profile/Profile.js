import { useContext, useState, useEffect, Fragment } from "react";
import { Context } from "Context";
import { mapString, getLoginUrl } from "utils";
import Link from "components/shared/Link";
import Icon from "components/shared/Icon";
import Card from "./Card";
import MessageCountBadge from "./MessageCountBadge";
import NotificationsModalContent from "./NotificationsModalContent";
import { brands } from "config.json";

const accountContainer = "accountContainer";
const containerClass = "syndicated-profile__container";
const messagesProperty = "received-invitations";
const targetOneId = "ngeGate";

const Profile = ({
	userStatusLinks = false, //if true, it should render sign In/sign out links
	username = false, //if true, it should render username link
	reservation = false, //if true, it should render reservation link (available only in aulani and only rendered when the user is logged-in)
	card = false, //if true, card component is rendered (link with the logged-in user's avatar)
	oneId = false, //if true, the component passed in the renderComponent prop gets a handleClick event attached to integrate with OneId
	target = null, //if not empty and oneId prop is true, then a handleClick event is attached to integrate with OneId
	showIcon = false, //if true, the link(s) will be rendered with the icon(s) coming from content
	notLoggedIn = false, //if true, the handleClick will only be attached to the component rendered by renderComponent if the user is not logged-in
	renderComponent = null, //function with the component to which adds the handleClick event with the OneId integration
	redirectOnLogin = false, //if true, a redirection is made after logging in
}) => {
	const {
		config: { brand, profile },
		profileData: {
			isLoading,
			user = null,
			isOneIdSource,
			handleClick,
			setUser,
			handleLogin,
			handleLogout,
			handleProfile,
			travelAgent,
		} = {},
		headerData,
		setModal,
	} = useContext(Context);
	const [messages, setMessages] = useState([]);
	const [isUpdatingMessages, setIsUpdatingMessages] = useState(false);
	const brandConfig = brands?.[brand];
	const isUserTypeRequired = brandConfig?.isUserTypeRequiredForContentRequest;
	const {
		signedIn,
		travelAgentSignedIn,
		signOut,
		travelAgentSignOut,
		signIn,
		travelAgentSignIn,
		reservationContent,
		reservationIcon,
		profile: profileContent,
		card: cardContent,
		defaultAvatarTitle,
		createAccount,
		orLabel,
	} = headerData.chrome || {};
	const signedInContent = signedIn || travelAgentSignedIn;
	const signOutContent = signOut || travelAgentSignOut;
	const signInContent = signIn || travelAgentSignIn;

	useEffect(() => {
		if (user?.messages) {
			setMessages(user?.messages[messagesProperty]);
			if (isUpdatingMessages) {
				setModal({ content: modalContent() });
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [user]);

	if (isLoading) return null;

	if (renderComponent && oneId) {
		const handleClickAttached = (e) => {
			if (target !== targetOneId) return null;
			if (!profile || !isOneIdSource || (notLoggedIn && user)) return null;
			if (user)
				handleProfile(e, redirectOnLogin ? e?.currentTarget?.href : null);
			else handleLogin(e, redirectOnLogin ? e?.currentTarget?.href : null);
		};
		return renderComponent(handleClickAttached);
	}

	if (!profile) return null;

	const handleShowNotifications = () => {
		setModal({ content: modalContent() });
	};

	const handleHideNotifications = () => {
		setModal(false);
	};

	const handleUpdateNotifications = (messageToRemove) => {
		setIsUpdatingMessages(true);
		const updatedMessages = messages.filter(
			(element) => element.links.self.href !== messageToRemove
		);
		const updatedUser = { ...user };
		updatedUser.messages[messagesProperty] = updatedMessages;
		setUser({ ...updatedUser });
		setMessages([...updatedMessages]);
	};

	const modalContent = () => {
		return (
			<NotificationsModalContent
				action={handleHideNotifications}
				updateNotificationsAction={handleUpdateNotifications}
				messages={messages}
			/>
		);
	};

	return headerData.chrome ? (
		user || (travelAgent?.firstName && isUserTypeRequired) ? (
			<Fragment>
				{username && signedInContent && (
					<div
						className={`${accountContainer} ${containerClass} ${containerClass}--guest ${containerClass}--${brand}`}
					>
						<Link
							{...signedInContent}
							className={`${containerClass}__link--guest guestSensitive`}
							title={mapString(
								signedInContent.title,
								(user || travelAgent)?.firstName
							)}
							handleClick={(event) => handleProfile(event)}
						/>
						{messages && (
							<MessageCountBadge
								action={handleShowNotifications}
								counter={messages.length}
							/>
						)}
					</div>
				)}
				{reservation && reservationContent && (
					<div className={`${accountContainer} ${containerClass}`}>
						<Link {...reservationContent} className={`${containerClass}__link`}>
							{showIcon && (
								<Fragment>
									<Icon icon={reservationIcon} />
									{reservationContent?.title}
								</Fragment>
							)}
						</Link>
					</div>
				)}
				{userStatusLinks && signOutContent && (
					<div className={`${accountContainer} ${containerClass}`}>
						<Link
							{...signOutContent}
							className={`${containerClass}__link signOut`}
							handleClick={(event) => handleLogout(event)}
						>
							{showIcon && (
								<Fragment>
									<Icon icon={profileContent?.icon} />
									{signOutContent.title}
								</Fragment>
							)}
						</Link>
					</div>
				)}
				{card && cardContent && (
					<Card
						username={user?.firstName}
						avatar={user?.avatar}
						content={{
							...cardContent,
							defaultAvatarTitle,
						}}
					/>
				)}
			</Fragment>
		) : userStatusLinks && (signInContent || createAccount) ? (
			<div className={`${accountContainer} ${containerClass}`}>
				{signInContent && (
					<Link
						{...signInContent}
						href={getLoginUrl(signInContent.href)}
						className={`${containerClass}__link signIn`}
						handleClick={(event) => handleLogin(event)}
					>
						{showIcon && !createAccount && (
							<Fragment>
								<Icon icon={profileContent?.icon} />
								{signInContent?.title}
							</Fragment>
						)}
					</Link>
				)}
				<span>{orLabel}</span>
				{createAccount && (
					<Link
						{...createAccount}
						className={`${containerClass}__link`}
						handleClick={handleClick("launchRegistration")}
					/>
				)}
			</div>
		) : null
	) : null;
};

export default Profile;
