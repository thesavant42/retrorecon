import React, { Fragment, useState, useEffect, useContext } from "react";
import Loading from "components/shared/Loading";
import Separator from "components/shared/Separator";
import Button from "components/shared/Button";
import Link from "components/shared/Link";
import useFetch from "hooks/useFetch";
import { Context } from "Context";
import { mapString } from "utils";
import { getCookie } from "utils/cookie";
import useLocalStorage from "hooks/useLocalStorage";
import config from "config.json";

const NotificationsModalContent = (props) => {
	const [syndicatedDismissButton, setSyndicatedDismissButton] = useLocalStorage(
		"syndicatedDismissButton",
		false
	);
	const { origin } = window.location;
	const swidCookieName = "SWID";
	const authTokenCookieName = "pep_oauth_token";
	const {
		headerData: {
			interstitial: { interstitialNotificationsModal },
		},
	} = useContext(Context);
	const [swid, setSwid] = useState(null);
	const [authToken, setAuthToken] = useState(null);
	const { messages, updateNotificationsAction } = props;
	const mainClass = "syndicated-notifications-modal";
	const [fetchTrigger, setFetchTrigger] = useState(0);
	const [optionParams, setOptionsParams] = useState(null);
	const [requestUrl, setRequestUrl] = useState("");
	const { response } = useFetch(
		requestUrl ? requestUrl : "",
		optionParams,
		0,
		fetchTrigger
	);

	const handleNotificationAction = (links, operationType) => {
		if (!operationType) {
			return null;
		}

		let invitationId;
		const hrefData = links[operationType].href;
		const options = links[operationType].post;

		const apiUrl = config.profile.apiUrl;
		const friendSwid = hrefData.split("/")[3] || "";
		const headers = {
			...options.headers,
			swid: swid,
			token: authToken,
		};

		setOptionsParams({
			method: "PUT",
			headers,
			body: JSON.stringify(options.body),
		});
		switch (operationType) {
			case "accept":
				invitationId = links[operationType].post.body["invitation-id"];
				setRequestUrl(
					`${apiUrl}/${friendSwid}/${operationType}/${invitationId}`
				);
				updateNotificationsAction(links.self.href);
				setFetchTrigger((fetch) => fetch + 1);
				break;
			case "decline":
				invitationId = hrefData.split("/")[5] || "";
				setRequestUrl(
					`${apiUrl}/${friendSwid}/${operationType}/${invitationId}`
				);
				updateNotificationsAction(links.self.href);
				setFetchTrigger((fetch) => fetch + 1);
				break;
			default:
				return;
		}

		return true;
	};

	const toggleElement = (elems) => {
		const elemsArray = elems.split(" ");
		elemsArray.forEach((item) => {
			const toggleElem = document.querySelector(item);
			toggleElem.classList.toggle(`${mainClass}${"--hidden"}`);
		});

		if (elems.indexOf(".top") >= 0) {
			setSyndicatedDismissButton(true);
		}
	};

	useEffect(() => {
		if (response !== null) {
			if (interstitialNotificationsModal.redirectLink) {
				window.location.assign(
					`${origin}/${interstitialNotificationsModal.redirectLink}`
				);
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [response]);

	useEffect(() => {
		try {
			const authTokenCookie = getCookie(authTokenCookieName);
			const swidCookie = getCookie(swidCookieName);

			authTokenCookie && setAuthToken(authTokenCookie);
			swidCookie && setSwid(swidCookie);
		} catch (error) {
			console.error(error);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<Fragment>
			<div className={`${mainClass}${"__title-bar"}`}>
				<h1>{interstitialNotificationsModal.title}</h1>
			</div>
			<div className={`${mainClass}${"__container"}`}>
				<div className={`${mainClass}${"__messages-list"}`}>
					{messages ? (
						messages.map((message, index) => (
							<div
								className={`${mainClass}${"__message-item"} guestSensitive`}
								key={index}
							>
								<span className={"message-bullet"}>•</span>{" "}
								{mapString(
									interstitialNotificationsModal.invitationMessage,
									`${message.issuedBy.firstName} ${message.issuedBy.lastName}`
								)}
								<div className={`${mainClass}${"__option-links"}`}>
									<button
										className={`${mainClass}${"__button"}`}
										onClick={() =>
											handleNotificationAction(message.links, "accept")
										}
									>
										{interstitialNotificationsModal.invitationAccept}
									</button>{" "}
									|{" "}
									<button
										className={`${mainClass}${"__button"}`}
										onClick={() =>
											handleNotificationAction(message.links, "decline")
										}
									>
										{interstitialNotificationsModal.invitationDecline}
									</button>
								</div>
							</div>
						))
					) : (
						<Loading />
					)}
				</div>
				<button
					className={`${mainClass}${"__show-hide-legal-disclaimer"} ${mainClass}${"__button"}`}
					onClick={() => toggleElement(`.${mainClass}${"__legal-disclaimer"}`)}
				>
					{interstitialNotificationsModal.showHideLegalDisclaimer}
				</button>
				<div
					className={`${mainClass}${"__legal-disclaimer"} ${mainClass}${"--hidden"}`}
				>
					<div
						dangerouslySetInnerHTML={{
							__html: interstitialNotificationsModal.legalDisclaimer,
						}}
					></div>
				</div>
				{!syndicatedDismissButton && (
					<div className="top">
						<Separator horizontal />
					</div>
				)}
				{!syndicatedDismissButton && (
					<div className={`${mainClass}${"__footer"}`}>
						<div className={`${mainClass}${"__dismiss-text"}`}>
							<div
								className={`${mainClass}${"__dismiss-text--description"}`}
								dangerouslySetInnerHTML={{
									__html: interstitialNotificationsModal.description,
								}}
							></div>{" "}
							<Link
								href={interstitialNotificationsModal.webLink.href}
								title={interstitialNotificationsModal.webLink.title}
							/>
						</div>
						<div className={`${mainClass}${"__dismiss-button"}`}>
							<button
								className={`modal-dismiss-link ${mainClass}${"__button"}`}
								onClick={() => toggleElement(`.${mainClass}${"__footer"} .top`)}
							>
								{interstitialNotificationsModal.dismiss}
							</button>
						</div>
					</div>
				)}
			</div>
			<Separator horizontal />
			<div className={`${mainClass}${"__modal-buttons"}`}>
				<Button
					className={`${mainClass}${"__button-check-out"}`}
					onClick={props.action}
					title={interstitialNotificationsModal.secondaryButton}
				/>
			</div>
		</Fragment>
	);
};

export default NotificationsModalContent;
