import Container from "components/shared/Container";
import useLocalStorage from "hooks/useLocalStorage";
import { useContext } from "react";
import { Context } from "Context";
import { mobileApplications } from "config.json";
import { mapString, getCdn } from "utils";
import Link from "components/shared/Link";
import Image from "components/shared/Image";

const smartBannerClass = "syndicated-smart-banner";
const pathname = window.location.pathname;

const SmartBanner = () => {
	const [toggle, setToggle] = useLocalStorage("smartBanner", true);
	const {
		headerData: { appBanner },
		config: { operatingSystem },
	} = useContext(Context);

	if (
		!toggle ||
		!appBanner ||
		!["ios", "android"].includes(operatingSystem) ||
		!appBanner?.descriptions?.sections?.[operatingSystem] ||
		(!appBanner?.pages?.includes("*") && !appBanner?.pages?.includes(pathname))
	) {
		return null;
	}

	const bannerContent = appBanner.descriptions.sections;

	return (
		<div className={smartBannerClass}>
			<Container direction="row">
				<Image
					image={{
						url: `${getCdn()}/logos/mobileApps/${bannerContent.logo}.png`,
						alt: bannerContent.title,
					}}
					name="smart-banner-icon"
				/>
				<div className={`${smartBannerClass}__content`}>
					<div className={`${smartBannerClass}__content__title`}>
						{bannerContent.title}
					</div>
					<div className={`${smartBannerClass}__content__subtitle`}>
						{bannerContent[operatingSystem].subtitle}
					</div>
				</div>
				<Link
					href={`${mapString(
						mobileApplications[operatingSystem],
						bannerContent[operatingSystem].id
					)}`}
					target="_blank"
					className={`${smartBannerClass}__open`}
				>
					{appBanner.buttonLabel}
				</Link>
				<div
					className={`${smartBannerClass}__close`}
					tabIndex="0"
					onClick={() => setToggle((prevState) => !prevState)}
					style={{
						backgroundImage: `url(${getCdn(
							true
						)}/icons/message-center/close.svg)`,
					}}
				>
					x
				</div>
			</Container>
		</div>
	);
};

export default SmartBanner;
