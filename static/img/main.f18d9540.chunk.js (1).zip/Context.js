import { createContext, useEffect, useState } from "react";
import {
	currentScript,
	getParam,
	loadAffiliations,
	loadAppConfiguration,
	loadBrandParam,
	loadLocaleParam,
	validateParam,
	validateParams,
	validateParamValue,
} from "utils/paramsValidation";
import { loadExternalThemeStyles } from "utils/theme";
import useProfile from "hooks/useProfile";
import { getDefaultLocale } from "utils/language";
import { getOperatingSystem } from "utils/clientDetails";
import { defaultLocale, defaultPosition, brands } from "config.json";
import { getEnvironment } from "utils";

export const Context = createContext();

const timeToReloadParameters = 100;
const contextEvent = "navigationContext";

const ContextProvider = (props) => {
	const [config, setConfig] = useState({
		allowedLocales: "",
		brand: loadBrandParam(),
		chrome: false,
		chromeLinks: true,
		footer: false,
		header: false,
		languageSelector: true,
		legal: false,
		locale: defaultLocale,
		messageCenter: true,
		navigation: false,
		operatingSystem: getOperatingSystem(),
		position: defaultPosition,
		profile: true,
		searchBar: true,
		secondaryMessage: true,
		showSections: true,
		showRelatedDisneySites: true,
		smartBanner: true,
		store: "",
		travelTrade: true,
		affiliations: [],
		basePath: "",
		showDisney: true,
		logo: true,
		theme: "",
		environment: getEnvironment(),
	});
	const [headerData, setHeaderData] = useState({ loading: true });
	const [footerData, setFooterData] = useState({ loading: true });
	const [legalFooterData, setLegalFooterData] = useState({ loading: true });
	const profileData = useProfile(
		config.brand,
		config.locale,
		config.profile,
		config.store,
		config.affiliations,
		headerData?.chrome
	);
	const [modal, setModal] = useState(null);

	const loadConfiguration = () => {
		setConfig((currentConfig) => ({
			...currentConfig,
			allowedLocales: getParam("allowedLocales"),
			chrome:
				validateParam("chrome") ||
				(validateParam("header") && !validateParam("hideNavigation")),
			chromeLinks: validateParam("chromeLinks", true),
			footer: validateParam("footer"),
			header: validateParams(["header", "chrome", "navigation"]),
			languageSelector: validateParam("languageSelector", true),
			legal: validateParam("legal"),
			locale: loadLocaleParam(),
			messageCenter: validateParam("messageCenter", true),
			navigation:
				validateParams(["header", "navigation"]) &&
				!validateParam("hideNavigation"),
			position: validateParamValue("position", ["top", "sticky"]),
			profile: validateParam("profile", true),
			searchBar: validateParam("searchBar", true),
			secondaryMessage: validateParam("secondaryMessage", true),
			showRelatedDisneySites: validateParam("showRelatedDisneySites", true),
			showSections: validateParam("showSections", true),
			smartBanner: validateParam("smartBanner", true),
			store: getParam("store"),
			travelTrade: validateParam("travelTrade", true),
			affiliations: loadAffiliations(),
			showDisney: validateParam("showDisney", true),
			logo: validateParam("logo", true),
			theme: getParam("theme"),
		}));
	};

	useEffect(() => {
		if (config.locale) {
			const defaultLocale = getDefaultLocale(config.brand);
			let basePath = config.locale === defaultLocale ? "" : `/${config.locale}`;
			if (basePath && brands?.[config.brand]?.allowedLocales?.[config.locale]) {
				basePath = `/${brands[config.brand].allowedLocales[config.locale]}`;
			}
			setConfig((config) => ({ ...config, basePath }));
		}
	}, [config.locale, config.brand]);

	useEffect(() => {
		setConfig((currentConfig) => ({
			...currentConfig,
			...(legalFooterData?.context || {}),
			...(footerData?.context || {}),
			...(headerData?.context || {}),
		}));
	}, [headerData, footerData, legalFooterData]);

	useEffect(() => {
		loadConfiguration();
		let observer;
		if (currentScript) {
			observer = new MutationObserver((changes) => {
				changes.forEach((change) => {
					if (change.attributeName.includes("src")) {
						loadAppConfiguration();
						loadConfiguration();
					}
				});
			});
			observer.observe(currentScript, { attributes: true });
			setTimeout(() => {
				loadAppConfiguration();
				loadConfiguration();
			}, timeToReloadParameters);
		}
		const contextEventLogic = (event) => {
			setConfig((config) => {
				const newConfig = { ...config, ...(event?.detail || {}) };
				console.log(newConfig);
				loadExternalThemeStyles(event?.detail?.theme);
				return newConfig;
			});
		};
		document.addEventListener(contextEvent, contextEventLogic);
		return () => {
			document.removeEventListener(contextEvent, contextEventLogic);
			if (observer) {
				observer.disconnect();
			}
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<Context.Provider
			value={{
				config,
				profileData,
				headerData,
				setHeaderData,
				footerData,
				setFooterData,
				legalFooterData,
				setLegalFooterData,
				modal,
				setModal,
				setConfig,
			}}
		>
			{props.children}
		</Context.Provider>
	);
};

export default ContextProvider;
